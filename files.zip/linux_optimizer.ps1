#!/usr/bin/env pwsh
<#
==========================================================================
    LINUX SYSTEM OPTIMIZER CLI — V1.0
    Companion do Windows Optimizer Pro V5.2
==========================================================================
    Repositorio: github.com/windows-optimizer-pro
    MIT License | 2026
    Compativel: PowerShell 7+ em Ubuntu, Debian, Fedora, Arch, openSUSE

    USO:
        sudo pwsh linux_optimizer.ps1
        sudo pwsh linux_optimizer.ps1 -Auto      (sem prompts)
        sudo pwsh linux_optimizer.ps1 -Report     (so relatorio)

    FUNCOES:
    - Analise IA do sistema (CPU, RAM, disco, servicos)
    - Limpeza de cache do sistema e de apps
    - Limpeza de cache de navegadores (Chrome, Firefox, Brave)
    - Limpeza de pacotes orfaos (apt/dnf/pacman)
    - Analise de DNS e latencia
    - Relatorio completo exportavel
    - Score de saude do sistema (0-1000)
==========================================================================
#>

param(
    [switch]$Auto,
    [switch]$Report
)

# --- Verificar PowerShell 7+ ---
if ($PSVersionTable.PSVersion.Major -lt 7) {
    Write-Error "PowerShell 7+ necessario. Instale em: https://aka.ms/install-powershell"
    exit 1
}

# --- Verificar Linux ---
if (-not $IsLinux) {
    Write-Error "Este script e exclusivo para Linux. Use WindowsOptimizer_Pro_V5_2_ULTRA.ps1 no Windows."
    exit 1
}

# --- Verificar root ---
$isRoot = (id -u) -eq 0
if (-not $isRoot -and -not $Report) {
    Write-Warning "Algumas operacoes requerem sudo. Execute: sudo pwsh linux_optimizer.ps1"
}

# Cores
function Write-Header  { param([string]$T) Write-Host "`n  ═══════════════════════════════════════" -ForegroundColor DarkCyan; Write-Host "  $T" -ForegroundColor Cyan; Write-Host "  ═══════════════════════════════════════" -ForegroundColor DarkCyan }
function Write-OK      { param([string]$M) Write-Host "  [OK]      $M" -ForegroundColor Green }
function Write-Warn    { param([string]$M) Write-Host "  [AVISO]   $M" -ForegroundColor Yellow }
function Write-Crit    { param([string]$M) Write-Host "  [CRITICO] $M" -ForegroundColor Red }
function Write-Info    { param([string]$M) Write-Host "  [INFO]    $M" -ForegroundColor Gray }
function Write-Action  { param([string]$M) Write-Host "  [+]       $M" -ForegroundColor Cyan }
function Write-Freed   { param([long]$Bytes) $mb=[Math]::Round($Bytes/1MB,1); Write-Host "  [LIMPO]   $mb MB liberados" -ForegroundColor Magenta }

$Global:TotalFreed = 0
$Global:Score      = 1000
$Global:Recs       = @()

# ══════════════════════════════════════════════════════════
#  ANALISE IA DO SISTEMA LINUX
# ══════════════════════════════════════════════════════════
function Get-LinuxAIScore {
    Write-Header "ANALISE IA DO SISTEMA"

    # RAM
    try {
        $memInfo = Get-Content /proc/meminfo
        $totalKB = ($memInfo | Where-Object { $_ -match '^MemTotal:' }) -replace '\D',''
        $availKB = ($memInfo | Where-Object { $_ -match '^MemAvailable:' }) -replace '\D',''
        $totalGB = [Math]::Round([long]$totalKB / 1MB, 1)
        $usedKB  = [long]$totalKB - [long]$availKB
        $ramPct  = [Math]::Round(($usedKB / [long]$totalKB) * 100, 1)
        $freeGB  = [Math]::Round([long]$availKB / 1MB, 1)
        if ($ramPct -gt 88) { $Global:Score -= 140; Write-Crit "RAM $ramPct% — libere processos"; $Global:Recs += "Reinicie servicos pesados" }
        elseif ($ramPct -gt 75) { $Global:Score -= 80; Write-Warn "RAM $ramPct% — elevada" }
        else { Write-OK "RAM $ramPct% — OK   ($freeGB GB livre de $totalGB GB)" }
    } catch { Write-Warn "Nao foi possivel ler /proc/meminfo" }

    # CPU load
    try {
        $loadAvg = (Get-Content /proc/loadavg).Split(' ')[0]
        $cpuCount = (Get-Content /proc/cpuinfo | Where-Object { $_ -match '^processor' } | Measure-Object).Count
        $loadPct  = [Math]::Round(([float]$loadAvg / $cpuCount) * 100, 1)
        if ($loadPct -gt 90) { $Global:Score -= 80; Write-Crit "Load avg $loadAvg — CPU sobrecarregada" }
        elseif ($loadPct -gt 60) { $Global:Score -= 30; Write-Warn "Load avg $loadAvg — carga moderada" }
        else { Write-OK "Load avg $loadAvg — CPU normal ($cpuCount cores)" }
    } catch { Write-Warn "Nao foi possivel ler load avg" }

    # Disco raiz
    try {
        $dfLine  = (df -h / --output=pcent,avail 2>/dev/null | tail -1).Trim()
        $diskPct = [int]($dfLine -replace '%.*','').Trim()
        $diskAvail = ($dfLine -split '\s+')[1]
        if ($diskPct -gt 90) { $Global:Score -= 120; Write-Crit "Disco / em $diskPct% — espaco critico!" }
        elseif ($diskPct -gt 75) { $Global:Score -= 60; Write-Warn "Disco / em $diskPct% — pouco espaco ($diskAvail livre)" }
        else { Write-OK "Disco / em $diskPct% — OK ($diskAvail livre)" }
    } catch { Write-Warn "Nao foi possivel verificar disco" }

    # Swap
    try {
        $swapInfo = Get-Content /proc/swaps 2>$null
        if ($swapInfo -and $swapInfo.Count -gt 1) {
            $swLine  = $swapInfo[1] -split '\s+'
            $swTotal = [long]$swLine[2]
            $swUsed  = [long]$swLine[3]
            if ($swTotal -gt 0) {
                $swPct = [Math]::Round(($swUsed / $swTotal) * 100, 1)
                if ($swPct -gt 70) { $Global:Score -= 60; Write-Warn "Swap em $swPct% — RAM insuficiente para carga" }
                else { Write-OK "Swap em $swPct% — OK" }
            }
        } else { Write-Info "Sem swap configurado" }
    } catch {}

    # Atualizacoes pendentes
    try {
        if (Get-Command apt 2>$null) {
            $updates = (apt list --upgradable 2>/dev/null | Where-Object { $_ -match '/' } | Measure-Object).Count
            if ($updates -gt 50) { $Global:Score -= 80; Write-Warn "$updates atualizacoes pendentes — execute apt upgrade" }
            elseif ($updates -gt 10) { $Global:Score -= 30; Write-Warn "$updates atualizacoes pendentes" }
            else { Write-OK "$updates atualizacoes pendentes — sistema atualizado" }
        } elseif (Get-Command dnf 2>$null) {
            $updates = (dnf check-update 2>/dev/null | Where-Object { $_ -match '\.' } | Measure-Object).Count
            if ($updates -gt 0) { Write-Warn "$updates atualizacoes pendentes (dnf)" }
            else { Write-OK "Sistema atualizado (dnf)" }
        } elseif (Get-Command pacman 2>$null) {
            $updates = (pacman -Qu 2>/dev/null | Measure-Object).Count
            if ($updates -gt 0) { Write-Warn "$updates atualizacoes pendentes (pacman)" }
            else { Write-OK "Sistema atualizado (pacman)" }
        }
    } catch {}

    # Servicos com falha
    try {
        if (Get-Command systemctl 2>$null) {
            $failed = (systemctl --failed --no-legend 2>/dev/null | Where-Object { $_ -match 'failed' } | Measure-Object).Count
            if ($failed -gt 0) { $Global:Score -= 50; Write-Warn "$failed servico(s) com falha — systemctl --failed para detalhes" }
            else { Write-OK "Nenhum servico com falha" }
        }
    } catch {}

    if ($Global:Score -lt 0) { $Global:Score = 0 }
    $class = if ($Global:Score -ge 920) {"EXCELENTE"} elseif ($Global:Score -ge 800) {"OTIMO"} elseif ($Global:Score -ge 650) {"BOM"} elseif ($Global:Score -ge 450) {"REGULAR"} else {"RUIM"}
    Write-Host "`n  Score IA: $($Global:Score)/1000 [$class]" -ForegroundColor $(if($Global:Score -ge 800){"Green"}elseif($Global:Score -ge 550){"Yellow"}else{"Red"})
    return $class
}

# ══════════════════════════════════════════════════════════
#  LIMPEZA DE CACHE DO SISTEMA
# ══════════════════════════════════════════════════════════
function Invoke-LinuxSystemClean {
    Write-Header "LIMPEZA DE CACHE DO SISTEMA"

    # /tmp
    try {
        $tmpSize = (Get-ChildItem /tmp -Recurse -Force -EA SilentlyContinue | Measure-Object Length -Sum).Sum
        Get-ChildItem /tmp -Force -EA SilentlyContinue | Remove-Item -Recurse -Force -EA SilentlyContinue
        $Global:TotalFreed += $tmpSize
        Write-Action "Limpou /tmp  ($([Math]::Round($tmpSize/1MB,1)) MB)"
    } catch { Write-Warn "Sem permissao para limpar /tmp" }

    # /var/tmp (mais de 7 dias)
    try {
        $varTmp = Get-ChildItem /var/tmp -Force -EA SilentlyContinue | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-7) }
        $varSz  = ($varTmp | Measure-Object Length -Sum).Sum
        $varTmp | Remove-Item -Recurse -Force -EA SilentlyContinue
        $Global:TotalFreed += $varSz
        Write-Action "Limpou /var/tmp (arquivos > 7 dias)  ($([Math]::Round($varSz/1MB,1)) MB)"
    } catch {}

    # Journald logs
    try {
        if (Get-Command journalctl 2>$null) {
            $before = (journalctl --disk-usage 2>/dev/null)
            journalctl --vacuum-time=7d 2>$null | Out-Null
            Write-Action "Journald: retidos ultimos 7 dias"
        }
    } catch {}

    # apt/dnf/pacman cache
    if (Get-Command apt-get 2>$null) {
        try {
            $cacheDir = "/var/cache/apt/archives"
            if (Test-Path $cacheDir) {
                $sz = (Get-ChildItem $cacheDir -Filter "*.deb" -EA SilentlyContinue | Measure-Object Length -Sum).Sum
                apt-get clean 2>$null | Out-Null
                $Global:TotalFreed += $sz
                Write-Action "apt cache limpo  ($([Math]::Round($sz/1MB,1)) MB)"
            }
            apt-get autoremove -y 2>$null | Out-Null
            Write-Action "Pacotes orfaos removidos (apt autoremove)"
        } catch { Write-Warn "apt-get clean requer sudo" }
    } elseif (Get-Command dnf 2>$null) {
        try {
            dnf clean all 2>$null | Out-Null
            Write-Action "dnf cache limpo"
            dnf autoremove -y 2>$null | Out-Null
            Write-Action "Pacotes orfaos removidos (dnf autoremove)"
        } catch { Write-Warn "dnf clean requer sudo" }
    } elseif (Get-Command pacman 2>$null) {
        try {
            pacman -Sc --noconfirm 2>$null | Out-Null
            Write-Action "pacman cache limpo"
        } catch { Write-Warn "pacman -Sc requer sudo" }
    }

    # Cache do usuario
    $userCache = "$HOME/.cache"
    if (Test-Path $userCache) {
        try {
            $sz = (Get-ChildItem $userCache -Recurse -Force -EA SilentlyContinue | Measure-Object Length -Sum).Sum
            Get-ChildItem $userCache -Force -EA SilentlyContinue | Remove-Item -Recurse -Force -EA SilentlyContinue
            $Global:TotalFreed += $sz
            Write-Action "~/.cache limpo  ($([Math]::Round($sz/1MB,1)) MB)"
        } catch {}
    }

    # Thumbnails
    $thumbDir = "$HOME/.thumbnails"
    if (Test-Path $thumbDir) {
        try {
            $sz = (Get-ChildItem $thumbDir -Recurse -Force -EA SilentlyContinue | Measure-Object Length -Sum).Sum
            Remove-Item "$thumbDir/*" -Recurse -Force -EA SilentlyContinue
            $Global:TotalFreed += $sz
            Write-Action "Thumbnails limpos  ($([Math]::Round($sz/1MB,1)) MB)"
        } catch {}
    }

    Write-OK "Limpeza do sistema concluida. Total liberado: $([Math]::Round($Global:TotalFreed/1MB,1)) MB"
}

# ══════════════════════════════════════════════════════════
#  LIMPEZA DE NAVEGADORES
# ══════════════════════════════════════════════════════════
function Invoke-LinuxBrowserClean {
    Write-Header "LIMPEZA DE CACHE DE NAVEGADORES"

    $browsers = @{
        "Chrome"   = "$HOME/.config/google-chrome/Default/Cache", "$HOME/.config/google-chrome/Default/Code Cache", "$HOME/.config/google-chrome/Default/GPUCache"
        "Chromium" = "$HOME/.config/chromium/Default/Cache", "$HOME/.config/chromium/Default/Code Cache"
        "Firefox"  = (Get-ChildItem "$HOME/.mozilla/firefox" -Filter "*.default*" -Directory -EA SilentlyContinue | ForEach-Object { $_.FullName + "/cache2/entries", $_.FullName + "/startupCache" })
        "Brave"    = "$HOME/.config/BraveSoftware/Brave-Browser/Default/Cache", "$HOME/.config/BraveSoftware/Brave-Browser/Default/Code Cache"
        "Edge"     = "$HOME/.config/microsoft-edge/Default/Cache", "$HOME/.config/microsoft-edge/Default/Code Cache"
    }

    foreach ($browser in $browsers.Keys) {
        $paths  = $browsers[$browser]
        $found  = $false
        $freed  = 0
        foreach ($p in $paths) {
            if (Test-Path $p) {
                $found = $true
                try {
                    $sz = (Get-ChildItem $p -Recurse -Force -EA SilentlyContinue | Measure-Object Length -Sum).Sum
                    Get-ChildItem $p -Force -EA SilentlyContinue | Remove-Item -Recurse -Force -EA SilentlyContinue
                    $freed += $sz
                } catch {}
            }
        }
        if ($found) {
            $Global:TotalFreed += $freed
            Write-Action "Cache $browser limpo  ($([Math]::Round($freed/1MB,1)) MB)"
        }
    }
    Write-OK "Cache de navegadores limpo"
}

# ══════════════════════════════════════════════════════════
#  ANALISE DE REDE
# ══════════════════════════════════════════════════════════
function Get-LinuxNetworkAnalysis {
    Write-Header "ANALISE DE REDE"

    # DNS configurado
    try {
        $resolv = Get-Content /etc/resolv.conf 2>$null | Where-Object { $_ -match '^nameserver' }
        if ($resolv) { Write-Info "DNS: $($resolv -join ' | ')" }
    } catch {}

    # Latencia
    $servers = @{ "Google 8.8.8.8" = "8.8.8.8"; "Cloudflare 1.1.1.1" = "1.1.1.1"; "OpenDNS 208.67.222.222" = "208.67.222.222" }
    $best = ""; $bestLat = 9999
    foreach ($name in $servers.Keys) {
        try {
            $pingResult = ping -c 2 -W 2 $servers[$name] 2>$null | Select-String 'avg'
            if ($pingResult) {
                $lat = [float](($pingResult.ToString() -split '/')[-3])
                Write-Info "$name — $lat ms"
                if ($lat -lt $bestLat) { $bestLat = $lat; $best = $name }
            } else { Write-Info "$name — Timeout" }
        } catch {}
    }
    if ($best) { Write-OK "DNS mais rapido: $best ($bestLat ms)" }

    # Interfaces
    try {
        $ifaces = ip addr show 2>$null | Where-Object { $_ -match 'inet ' -and $_ -notmatch '127.0.0.1' }
        $ifaces | ForEach-Object { Write-Info "Interface: $($_.Trim())" }
    } catch {}
}

# ══════════════════════════════════════════════════════════
#  RELATORIO
# ══════════════════════════════════════════════════════════
function Export-LinuxReport {
    $path = "$HOME/Desktop/LinuxOptimizer_Report_$(Get-Date -Format 'yyyyMMdd_HHmm').txt"
    if (-not (Test-Path "$HOME/Desktop")) { $path = "$HOME/LinuxOptimizer_Report_$(Get-Date -Format 'yyyyMMdd_HHmm').txt" }

    $uname  = (uname -a)
    $uptm   = (uptime)
    $dfout  = (df -h)
    $meminf = (free -h)
    $cpuinf = (lscpu | head -20)

    $content = @"
==========================================================================
  LINUX SYSTEM OPTIMIZER — RELATORIO
  Data: $(Get-Date -Format 'dd/MM/yyyy HH:mm:ss')
  GitHub: github.com/windows-optimizer-pro | MIT 2026
==========================================================================

SISTEMA
  $uname
  Uptime: $uptm

PROCESSADOR
$cpuinf

MEMORIA
$meminf

DISCO
$dfout

SCORE IA: $($Global:Score)/1000
TOTAL LIBERADO: $([Math]::Round($Global:TotalFreed/1MB,1)) MB

RECOMENDACOES
$($Global:Recs -join "`n")
==========================================================================
"@
    $content | Out-File -FilePath $path -Encoding UTF8
    Write-OK "Relatorio exportado: $path"
}

# ══════════════════════════════════════════════════════════
#  MENU PRINCIPAL
# ══════════════════════════════════════════════════════════
function Show-Menu {
    Clear-Host
    Write-Host ""
    Write-Host "  ============================================================" -ForegroundColor DarkCyan
    Write-Host "    LINUX SYSTEM OPTIMIZER V1.0" -ForegroundColor Cyan
    Write-Host "    Companion do Windows Optimizer Pro V5.2" -ForegroundColor Gray
    Write-Host "    MIT License | github.com/windows-optimizer-pro" -ForegroundColor Gray
    Write-Host "  ============================================================" -ForegroundColor DarkCyan
    Write-Host ""
    Write-Host "  [1] Analise IA completa do sistema" -ForegroundColor White
    Write-Host "  [2] Limpeza de cache do sistema" -ForegroundColor White
    Write-Host "  [3] Limpeza de cache de navegadores" -ForegroundColor White
    Write-Host "  [4] Analise de rede e DNS" -ForegroundColor White
    Write-Host "  [5] TUDO (analise + limpeza completa)" -ForegroundColor Green
    Write-Host "  [6] Exportar relatorio TXT" -ForegroundColor White
    Write-Host "  [Q] Sair" -ForegroundColor Red
    Write-Host ""
    $choice = Read-Host "  Escolha"
    return $choice.ToUpper()
}

# ══════════════════════════════════════════════════════════
#  EXECUCAO
# ══════════════════════════════════════════════════════════
if ($Report) {
    Get-LinuxAIScore | Out-Null
    Export-LinuxReport
    exit 0
}

if ($Auto) {
    Get-LinuxAIScore | Out-Null
    Invoke-LinuxSystemClean
    Invoke-LinuxBrowserClean
    Get-LinuxNetworkAnalysis
    Export-LinuxReport
    Write-Host "`n  Total liberado: $([Math]::Round($Global:TotalFreed/1MB,1)) MB`n" -ForegroundColor Green
    exit 0
}

# Modo interativo
do {
    $choice = Show-Menu
    switch ($choice) {
        '1' { Get-LinuxAIScore | Out-Null }
        '2' { Invoke-LinuxSystemClean }
        '3' { Invoke-LinuxBrowserClean }
        '4' { Get-LinuxNetworkAnalysis }
        '5' {
            Get-LinuxAIScore | Out-Null
            Invoke-LinuxSystemClean
            Invoke-LinuxBrowserClean
            Get-LinuxNetworkAnalysis
            Write-Host "`n  Total liberado: $([Math]::Round($Global:TotalFreed/1MB,1)) MB" -ForegroundColor Magenta
        }
        '6' { Export-LinuxReport }
        'Q' { Write-Host "`n  Ate mais!`n" -ForegroundColor Cyan; exit 0 }
        default { Write-Host "  Opcao invalida." -ForegroundColor Red }
    }
    if ($choice -ne 'Q') {
        Write-Host "`n  Pressione ENTER para continuar..." -ForegroundColor DarkGray
        Read-Host | Out-Null
    }
} while ($choice -ne 'Q')
