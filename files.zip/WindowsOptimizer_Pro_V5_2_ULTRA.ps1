﻿#Requires -RunAsAdministrator
<#
==========================================================================
    WINDOWS OPTIMIZER PRO V5.2 ULTRA PRO
==========================================================================
    GitHub Ready | MIT License | 2026
    Repositorio: github.com/windows-optimizer-pro

    NOVIDADES V5.2:
    - Ponto de restauracao automatico ANTES de qualquer alteracao
    - Backup de registry antes de modificar chaves criticas
    - Botoes "Restaurar Padrao" para pagefile, DNS, telemetria, rede
    - Gamer Mode: texto cauteloso/realista, disclaimer de ganhos variaveis
    - Disclaimer fixo visivel no rodape
    - FontSize minimo 14 nos textos, 16-18 nos titulos de secao
    - CornerRadius aumentado (10-12), espaçamentos maiores
    - Feedback toast temporario apos acoes (5s, sumeco suave)
    - Log de acoes em $env:TEMP\WinOptimizer_Log.txt
    - Timer top processos e rodape: 8s
    - Aviso RAM Clean se RAM livre < 20%
    - Analise Heuristica (nome atualizado de IA)
    - Modo pt-BR / en-US basico
    - Reversibilidade total em todas as alteracoes
    - Seguranca: nunca toca Defender/Update/Firewall/servicos criticos
==========================================================================
#>

if ($PSVersionTable.PSVersion.Major -lt 5) { Write-Error "PowerShell 5.1+ necessario"; Exit }
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase, System.Windows.Forms

Add-Type @"
using System;
using System.Runtime.InteropServices;
public class MemoryHelper {
    [DllImport("psapi.dll")] public static extern bool EmptyWorkingSet(IntPtr hProcess);
}
"@ -EA SilentlyContinue

$Global:SpaceFreed      = 0
$Global:GamerModeActive = $false
$Global:AppVersion      = "5.2 ULTRA PRO"
$Global:RegPath         = "HKCU:\SOFTWARE\WindowsOptimizerPro"
$Global:SnapshotBefore  = $null
$Global:Lang            = 'ptBR'
$Global:LogFile         = "$env:TEMP\WinOptimizer_Log.txt"

# ══════════════════════════════════════════════════════════
#  LOG DE ACOES
# ══════════════════════════════════════════════════════════
function Write-Log {
    param([string]$Action, [string]$Result = "OK")
    try {
        $line = "$(Get-Date -Format 'dd/MM/yyyy HH:mm:ss') | $Action | $Result"
        Add-Content -Path $Global:LogFile -Value $line -EA SilentlyContinue
    } catch {}
}

# ══════════════════════════════════════════════════════════
#  PONTO DE RESTAURACAO AUTOMATICO
# ══════════════════════════════════════════════════════════
function New-SafeRestorePoint {
    param([string]$Desc = "Windows Optimizer Pro V5.2")
    try {
        Enable-ComputerRestore -Drive "C:\" -EA SilentlyContinue
        Checkpoint-Computer -Description $Desc -RestorePointType "MODIFY_SETTINGS" -EA SilentlyContinue
        Write-Log "RestorePoint criado" $Desc
        return $true
    } catch { Write-Log "RestorePoint" "FALHOU: $_"; return $false }
}

# ══════════════════════════════════════════════════════════
#  BACKUP DE REGISTRY
# ══════════════════════════════════════════════════════════
function Backup-RegistryKey {
    param([string]$KeyPath, [string]$Tag = "backup")
    try {
        $safeTag = $Tag -replace '[^a-zA-Z0-9_]','_'
        $file = "$env:TEMP\WinOptimizer_RegBackup_$($safeTag)_$(Get-Date -Format 'yyyyMMdd_HHmmss').reg"
        $hiveMap = @{
            'HKLM' = 'HKEY_LOCAL_MACHINE'
            'HKCU' = 'HKEY_CURRENT_USER'
        }
        $hive = ($KeyPath -split ':\\')[0]
        $rest = ($KeyPath -split ':\\')[1]
        $fullKey = "$($hiveMap[$hive])\$rest"
        reg export "$fullKey" "$file" /y 2>$null | Out-Null
        Write-Log "BackupRegistry" "$file"
        return $file
    } catch { return $null }
}

# ══════════════════════════════════════════════════════════
#  ANALISE HEURISTICA V5.2 — 12 METRICAS
# ══════════════════════════════════════════════════════════
function Get-HeuristicScore {
    param([string]$Profile = 'Padrao')
    $score   = 1000
    $recs    = @()
    $details = @{}

    try {
        $OS  = Get-CimInstance Win32_OperatingSystem -EA SilentlyContinue
        $CPU = Get-CimInstance Win32_Processor -EA SilentlyContinue | Select-Object -First 1

        # Metrica 1: RAM
        $totalRAM = $OS.TotalVisibleMemorySize
        $freeRAM  = $OS.FreePhysicalMemory
        $ramPct   = [Math]::Round((($totalRAM - $freeRAM) / $totalRAM) * 100, 1)
        $wRAM = if ($Profile -eq 'Gamer') { 180 } elseif ($Profile -eq 'Trabalho') { 160 } else { 140 }
        if ($ramPct -gt 88)     { $score -= $wRAM;             $recs += "[CRITICO] RAM $($ramPct)% — libere apps urgente" }
        elseif ($ramPct -gt 75) { $score -= [int]($wRAM * .6); $recs += "[AVISO]   RAM $($ramPct)% — elevada" }
        elseif ($ramPct -gt 60) { $score -= [int]($wRAM * .2); $recs += "[INFO]    RAM $($ramPct)% — moderada" }
        else                    { $recs += "[OK]      RAM $($ramPct)% — saudavel" }
        $details['RAM'] = $ramPct

        # Metrica 2: Disco sistema
        $sysDisk = Get-CimInstance Win32_LogicalDisk -EA SilentlyContinue | Where-Object { $_.DeviceID -eq $env:SystemDrive }
        if ($sysDisk -and $sysDisk.Size -gt 0) {
            $diskPct = [Math]::Round((($sysDisk.Size - $sysDisk.FreeSpace) / $sysDisk.Size) * 100, 1)
            $wDisk   = if ($Profile -eq 'Gamer') { 100 } else { 120 }
            if ($diskPct -gt 92)     { $score -= $wDisk;             $recs += "[CRITICO] Disco $($diskPct)% — espaco critico" }
            elseif ($diskPct -gt 80) { $score -= [int]($wDisk * .6); $recs += "[AVISO]   Disco $($diskPct)% — pouco espaco" }
            elseif ($diskPct -gt 65) { $score -= [int]($wDisk * .2); $recs += "[INFO]    Disco $($diskPct)% — atencao" }
            else                     { $recs += "[OK]      Disco $($diskPct)% — OK" }
            $details['Disco'] = $diskPct
        }

        # Metrica 3: CPU Load
        try {
            $cpuLoad = [Math]::Round($CPU.LoadPercentage, 1)
            if ($cpuLoad -gt 85)     { $score -= 80; $recs += "[AVISO]   CPU $($cpuLoad)% — processo pesado rodando" }
            elseif ($cpuLoad -gt 60) { $score -= 30; $recs += "[INFO]    CPU $($cpuLoad)% — carga moderada" }
            else                     { $recs += "[OK]      CPU $($cpuLoad)% — normal" }
            $details['CPU'] = $cpuLoad
        } catch {}

        # Metrica 4: PageFile
        try {
            $pf = Get-CimInstance Win32_PageFileUsage -EA SilentlyContinue
            if ($pf -and $pf.AllocatedBaseSize -gt 0) {
                $pfPct = [Math]::Round(($pf.CurrentUsage / $pf.AllocatedBaseSize) * 100, 0)
                if ($pfPct -gt 70) { $score -= 60; $recs += "[AVISO]   PageFile $($pfPct)% — RAM insuficiente para carga" }
                else               { $recs += "[OK]      PageFile $($pfPct)% — OK" }
                $details['PageFile'] = $pfPct
            }
        } catch {}

        # Metrica 5: Telemetria
        $tel = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection" -Name AllowTelemetry -EA SilentlyContinue
        if ($null -eq $tel -or $tel.AllowTelemetry -ne 0) { $score -= 60; $recs += "[AVISO]   Telemetria ativa — dados enviados a Microsoft" }
        else { $recs += "[OK]      Telemetria desabilitada" }

        # Metrica 6: Startup Apps
        $stCount = 0
        try { $stCount = (Get-CimInstance Win32_StartupCommand -EA SilentlyContinue | Measure-Object).Count } catch {}
        $wSt = if ($Profile -eq 'Gamer') { 100 } else { 70 }
        if ($stCount -gt 20)     { $score -= $wSt;             $recs += "[AVISO]   $stCount apps no boot — boot lento" }
        elseif ($stCount -gt 12) { $score -= [int]($wSt * .5); $recs += "[INFO]    $stCount apps no boot" }
        else                     { $recs += "[OK]      $stCount apps no boot — bom" }
        $details['Startup'] = $stCount

        # Metrica 7: Windows Update (dias)
        try {
            $wu = Get-HotFix -EA SilentlyContinue | Sort-Object InstalledOn -Desc | Select-Object -First 1
            if ($wu -and $wu.InstalledOn) {
                $days = ((Get-Date) - ([DateTime]$wu.InstalledOn)).Days
                if ($days -gt 90)     { $score -= 80; $recs += "[CRITICO] Windows sem update ha $days dias" }
                elseif ($days -gt 45) { $score -= 40; $recs += "[AVISO]   Windows sem update ha $days dias" }
                else                  { $recs += "[OK]      Windows atualizado (ha $days dias)" }
                $details['WinUpdate'] = $days
            }
        } catch {}

        # Metrica 8: HDD detectado
        try {
            $hasHDD = Get-PhysicalDisk -EA SilentlyContinue | Where-Object { $_.MediaType -eq 'HDD' }
            if ($hasHDD) { $recs += "[INFO]    HDD detectado — desfragmentacao recomendada periodicamente" }
        } catch {}

        # Metrica 9: Temp files
        try {
            $tmpSz = (Get-ChildItem $env:TEMP -Recurse -Force -EA SilentlyContinue | Measure-Object Length -Sum).Sum
            $tmpMB = [Math]::Round($tmpSz / 1MB, 0)
            if ($tmpMB -gt 2000)    { $score -= 40; $recs += "[AVISO]   Temp files: $($tmpMB) MB — limpeza recomendada" }
            elseif ($tmpMB -gt 500) { $score -= 15; $recs += "[INFO]    Temp files: $($tmpMB) MB" }
            else                    { $recs += "[OK]      Temp files: $($tmpMB) MB — OK" }
            $details['TempMB'] = $tmpMB
        } catch {}

        # Metrica 10: Tasks terceiros
        try {
            $tpCount = (Get-ScheduledTask -EA SilentlyContinue | Where-Object {
                $_.TaskPath -notmatch '^\\Microsoft\\' -and $_.State -eq 'Ready' -and $_.TaskPath -ne '\'
            } | Measure-Object).Count
            if ($tpCount -gt 15) { $score -= 30; $recs += "[AVISO]   $tpCount tarefas de terceiros ativas" }
            else                 { $recs += "[OK]      $tpCount tarefas de terceiros — normal" }
            $details['ThirdTasks'] = $tpCount
        } catch {}

        # Metrica 11: Driver GPU (idade)
        try {
            $gpu = Get-CimInstance Win32_VideoController -EA SilentlyContinue | Select-Object -First 1
            if ($gpu -and $gpu.DriverDate) {
                $dAge = ((Get-Date) - $gpu.DriverDate).Days
                if ($dAge -gt 365) { $score -= 40; $recs += "[AVISO]   Driver GPU com $dAge dias — considere atualizar" }
                else               { $recs += "[OK]      Driver GPU: $dAge dias — recente" }
            }
        } catch {}

        # Metrica 12: Gamer Mode (perfil Gamer)
        if ($Profile -eq 'Gamer') {
            $gm    = Get-ItemProperty "HKCU:\SOFTWARE\Microsoft\GameBar" -Name AllowAutoGameMode -EA SilentlyContinue
            $hwSch = Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" -Name HwSchMode -EA SilentlyContinue
            if ($null -eq $gm -or $gm.AllowAutoGameMode -ne 1) { $score -= 80; $recs += "[GAMER]   Game Mode desativado — ative para ganhos" }
            else { $recs += "[GAMER]   Game Mode ativo" }
            if ($hwSch -and $hwSch.HwSchMode -eq 2) { $recs += "[GAMER]   HW GPU Scheduling ativo" }
            else { $score -= 30; $recs += "[GAMER]   HW GPU Scheduling desativado" }
        }

        if ($score -lt 0) { $score = 0 }
        $class = if ($score -ge 920) {"EXCELENTE"} elseif ($score -ge 800) {"OTIMO"} elseif ($score -ge 650) {"BOM"} elseif ($score -ge 450) {"REGULAR"} else {"RUIM"}
    } catch {
        $score = 500; $recs += "[ERRO] Falha na analise: $_"; $class = "ERRO"
    }
    return @{ Score = $score; Class = $class; Recommendations = $recs; Details = $details }
}

# ══════════════════════════════════════════════════════════
#  HISTORICO DO SCORE
# ══════════════════════════════════════════════════════════
function Save-ScoreHistory {
    param([int]$Score, [string]$Class)
    try {
        New-Item $Global:RegPath -Force -EA SilentlyContinue | Out-Null
        $histKey = "$($Global:RegPath)\ScoreHistory"
        New-Item $histKey -Force -EA SilentlyContinue | Out-Null
        $entry   = "$(Get-Date -Format 'dd/MM HH:mm') | $Score | $Class"
        $existing = @()
        for ($i = 1; $i -le 10; $i++) {
            $v = Get-ItemProperty $histKey -Name "Entry$i" -EA SilentlyContinue
            if ($v) { $existing += $v."Entry$i" }
        }
        $existing = @($entry) + $existing | Select-Object -First 10
        for ($i = 0; $i -lt $existing.Count; $i++) {
            New-ItemProperty $histKey -Name "Entry$($i+1)" -Value $existing[$i] -PropertyType String -Force -EA SilentlyContinue | Out-Null
        }
    } catch {}
}

function Get-ScoreHistory {
    $lines = @()
    try {
        $histKey = "$($Global:RegPath)\ScoreHistory"
        for ($i = 1; $i -le 10; $i++) {
            $v = Get-ItemProperty $histKey -Name "Entry$i" -EA SilentlyContinue
            if ($v) { $lines += $v."Entry$i" }
        }
    } catch {}
    return $lines
}

# ══════════════════════════════════════════════════════════
#  SNAPSHOT ANTES/DEPOIS
# ══════════════════════════════════════════════════════════
function Get-SystemSnapshot {
    try {
        $OS      = Get-CimInstance Win32_OperatingSystem -EA SilentlyContinue
        $hs      = Get-HeuristicScore
        $tmpMB   = 0
        $stCount = 0
        try { $tmpMB  = [Math]::Round((Get-ChildItem $env:TEMP -Recurse -Force -EA SilentlyContinue | Measure-Object Length -Sum).Sum / 1MB, 0) } catch {}
        try { $stCount = (Get-CimInstance Win32_StartupCommand -EA SilentlyContinue | Measure-Object).Count } catch {}
        return @{
            Time         = Get-Date
            Score        = $hs.Score
            Class        = $hs.Class
            RAMFreeGB    = [Math]::Round($OS.FreePhysicalMemory / 1MB, 2)
            TempMB       = $tmpMB
            StartupCount = $stCount
        }
    } catch { return $null }
}

function Show-ComparisonReport {
    if (-not $Global:SnapshotBefore) {
        [System.Windows.MessageBox]::Show("Nenhum snapshot capturado.`nClique em 'Capturar Estado Antes' primeiro.", "Comparativo", "OK", "Warning")
        return
    }
    $after     = Get-SystemSnapshot
    $b         = $Global:SnapshotBefore
    $scoreDiff = $after.Score - $b.Score
    $ramDiff   = [Math]::Round($after.RAMFreeGB - $b.RAMFreeGB, 2)
    $tempDiff  = $b.TempMB - $after.TempMB
    $sign      = if ($scoreDiff -ge 0) { "+" } else { "" }
    $ramSign   = if ($ramDiff   -ge 0) { "+" } else { "" }
    $msg = @"
RELATORIO COMPARATIVO ANTES vs DEPOIS
======================================

ANTES  ($($b.Time.ToString('dd/MM HH:mm')))
  Score Heuristico: $($b.Score)/1000  [$($b.Class)]
  RAM Livre:        $($b.RAMFreeGB) GB
  Temp Files:       $($b.TempMB) MB
  Startup Apps:     $($b.StartupCount)

DEPOIS ($($after.Time.ToString('dd/MM HH:mm')))
  Score Heuristico: $($after.Score)/1000  [$($after.Class)]
  RAM Livre:        $($after.RAMFreeGB) GB
  Temp Files:       $($after.TempMB) MB
  Startup Apps:     $($after.StartupCount)

GANHOS ESTIMADOS
  Score:   $($sign)$scoreDiff pontos
  RAM:     $($ramSign)$ramDiff GB liberados
  Temp:    +$($tempDiff) MB limpos

NOTA: Ganhos reais variam conforme hardware e uso.
"@
    [System.Windows.MessageBox]::Show($msg, "Antes vs Depois", "OK", "Information")
}

# ══════════════════════════════════════════════════════════
#  TOP 5 PROCESSOS
# ══════════════════════════════════════════════════════════
function Get-TopProcesses {
    try {
        $procs  = Get-Process -EA SilentlyContinue | Where-Object { $_.Id -ne 0 }
        $topRAM = $procs | Sort-Object WorkingSet64 -Desc | Select-Object -First 5
        $topCPU = $procs | Sort-Object CPU -Desc | Select-Object -First 5
        $out = @("TOP 5 POR RAM:")
        foreach ($p in $topRAM) { $out += "  $($p.Name.PadRight(26)) $([Math]::Round($p.WorkingSet64/1MB,0)) MB" }
        $out += @("", "TOP 5 POR CPU:")
        foreach ($p in $topCPU) { $out += "  $($p.Name.PadRight(26)) $([Math]::Round($p.CPU,1)) s" }
        return $out -join "`n"
    } catch { return "Erro ao obter processos" }
}

# ══════════════════════════════════════════════════════════
#  PAGEFILE INTELIGENTE + RESTAURACAO
# ══════════════════════════════════════════════════════════
function Invoke-PagefileOptimize {
    try {
        $OS     = Get-CimInstance Win32_OperatingSystem -EA SilentlyContinue
        $ramGB  = [Math]::Round($OS.TotalVisibleMemorySize / 1MB, 0)
        $initMB = [Math]::Min($ramGB * 1024, 16384)
        $maxMB  = [Math]::Min($ramGB * 1024 * 3, 32768)
        $drive  = $env:SystemDrive
        $curr   = Get-CimInstance Win32_PageFileSetting -EA SilentlyContinue
        $currInfo = if ($curr) { "Atual: Inicial=$($curr.InitialSize) MB / Max=$($curr.MaximumSize) MB" } else { "Atual: Gerenciado automaticamente (recomendado)" }
        $msg = "Configurar PageFile manualmente?`n`n$currInfo`n`nNovo (formula Microsoft):`n  RAM detectada: $($ramGB) GB`n  Inicial: $($initMB) MB`n  Maximo:  $($maxMB) MB`n`nAVISO: Em SSDs modernos, o gerenciamento automatico costuma ser melhor.`nUse configuracao manual so se souber o que esta fazendo.`n`nRequer reinicializacao para efeito total."
        $res = [System.Windows.MessageBox]::Show($msg, "PageFile Inteligente", "YesNo", "Question")
        if ($res -ne "Yes") { return }
        Backup-RegistryKey "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" "pagefile" | Out-Null
        $cs = Get-CimInstance Win32_ComputerSystem -EA SilentlyContinue
        $cs | Set-CimInstance -Property @{ AutomaticManagedPagefile = $false } -EA SilentlyContinue
        Get-CimInstance Win32_PageFileSetting -EA SilentlyContinue | Remove-CimInstance -EA SilentlyContinue
        New-CimInstance -ClassName Win32_PageFileSetting -Property @{
            Name        = "$drive\pagefile.sys"
            InitialSize = [uint32]$initMB
            MaximumSize = [uint32]$maxMB
        } -EA SilentlyContinue | Out-Null
        Write-Log "PageFile configurado" "Inicial=$initMB MaxMB=$maxMB"
        [System.Windows.MessageBox]::Show("PageFile configurado!`nInicial: $($initMB) MB`nMaximo:  $($maxMB) MB`n`nReinicie o PC para aplicar.", "PageFile OK", "OK", "Information")
    } catch {
        [System.Windows.MessageBox]::Show("Erro ao configurar PageFile: $_", "Aviso", "OK", "Warning")
        Start-Process "SystemPropertiesAdvanced.exe" -EA SilentlyContinue
    }
}

function Restore-PagefileAutomatic {
    $res = [System.Windows.MessageBox]::Show("Restaurar gerenciamento automatico do PageFile pelo Windows?`n`nEsta e a configuracao recomendada para a maioria dos usuarios.", "Restaurar PageFile", "YesNo", "Question")
    if ($res -ne "Yes") { return }
    try {
        $cs = Get-CimInstance Win32_ComputerSystem -EA SilentlyContinue
        $cs | Set-CimInstance -Property @{ AutomaticManagedPagefile = $true } -EA SilentlyContinue
        Write-Log "PageFile restaurado" "Automatico"
        [System.Windows.MessageBox]::Show("PageFile restaurado para gerenciamento automatico!`nReinicie o PC.", "PageFile", "OK", "Information")
    } catch { [System.Windows.MessageBox]::Show("Erro: $_", "Erro", "OK", "Error") }
}

# ══════════════════════════════════════════════════════════
#  SCHEDULED TASKS DE TERCEIROS
# ══════════════════════════════════════════════════════════
function Show-ThirdPartyTasks {
    try {
        $tasks = Get-ScheduledTask -EA SilentlyContinue | Where-Object {
            $_.TaskPath -notmatch '^\\Microsoft\\' -and
            $_.TaskPath -notmatch '^\\Windows\\' -and
            $_.State -ne 'Disabled'
        } | Sort-Object TaskPath
        if (-not $tasks -or $tasks.Count -eq 0) {
            [System.Windows.MessageBox]::Show("Nenhuma tarefa de terceiros ativa encontrada.", "Tasks", "OK", "Information"); return
        }
        $lines = @("TAREFAS AGENDADAS DE TERCEIROS ($($tasks.Count) encontradas)", "", "[R]=Ready  [Ru]=Running", "")
        foreach ($t in $tasks | Select-Object -First 30) {
            $st = switch ($t.State) { 3 {"[R] "} 4 {"[Ru]"} default {"[?] "} }
            $lines += "  $st $($t.TaskName.PadRight(35)) $($t.TaskPath.TrimStart('\'))"
        }
        if ($tasks.Count -gt 30) { $lines += "  ... e mais $($tasks.Count - 30) tarefas" }
        $lines += @("", "Abrir Agendador de Tarefas para gerenciar?")
        if ([System.Windows.MessageBox]::Show(($lines -join "`n"), "Tarefas de Terceiros", "YesNo", "Information") -eq "Yes") {
            Start-Process "taskschd.msc" -EA SilentlyContinue
        }
    } catch { [System.Windows.MessageBox]::Show("Erro: $_", "Erro", "OK", "Error") }
}

# ══════════════════════════════════════════════════════════
#  NETWORK ADAPTER ADVANCED + RESTAURACAO
# ══════════════════════════════════════════════════════════
function Invoke-NetworkAdapterAdvanced {
    try {
        $adapters = Get-NetAdapter | Where-Object { $_.Status -eq 'Up' -and $_.InterfaceDescription -notmatch 'Loopback|Virtual|Bluetooth' }
        if (-not $adapters) { [System.Windows.MessageBox]::Show("Nenhum adaptador fisico ativo.", "Rede", "OK", "Warning"); return }
        $applied = @()
        foreach ($a in $adapters) {
            $name = $a.Name
            try { Set-NetAdapterRss -Name $name -Enabled $true -EA SilentlyContinue; $applied += "+ RSS habilitado: $name" } catch {}
            try {
                if (Get-NetAdapterLso -Name $name -EA SilentlyContinue) {
                    Set-NetAdapterLso -Name $name -IPv4Enabled $true -IPv6Enabled $true -EA SilentlyContinue
                    $applied += "+ LSOv2 habilitado: $name"
                }
            } catch {}
            try {
                $imod = Get-NetAdapterAdvancedProperty -Name $name -EA SilentlyContinue | Where-Object { $_.RegistryKeyword -match 'InterruptModeration' }
                if ($imod) {
                    Set-NetAdapterAdvancedProperty -Name $name -RegistryKeyword $imod.RegistryKeyword -RegistryValue 0 -EA SilentlyContinue
                    $applied += "+ Interrupt Moderation OFF: $name"
                }
            } catch {}
            try {
                $flow = Get-NetAdapterAdvancedProperty -Name $name -EA SilentlyContinue | Where-Object { $_.RegistryKeyword -match 'FlowControl' }
                if ($flow) {
                    Set-NetAdapterAdvancedProperty -Name $name -RegistryKeyword $flow.RegistryKeyword -RegistryValue 0 -EA SilentlyContinue
                    $applied += "+ Flow Control OFF: $name"
                }
            } catch {}
        }
        $result = if ($applied.Count -gt 0) { $applied -join "`n" } else { "Configuracoes ja otimizadas." }
        Write-Log "NetAdapterAdvanced" $result
        [System.Windows.MessageBox]::Show("Adaptadores otimizados!`n`n$result", "Rede Avancada", "OK", "Information")
    } catch { [System.Windows.MessageBox]::Show("Erro: $_", "Erro", "OK", "Error") }
}

function Restore-NetworkAdapterDefaults {
    $res = [System.Windows.MessageBox]::Show("Restaurar configuracoes padrao dos adaptadores de rede?`n(RSS, LSO, Interrupt Moderation, Flow Control voltam ao padrao do driver)", "Restaurar Rede", "YesNo", "Question")
    if ($res -ne "Yes") { return }
    try {
        $adapters = Get-NetAdapter | Where-Object { $_.Status -eq 'Up' -and $_.InterfaceDescription -notmatch 'Loopback|Virtual|Bluetooth' }
        foreach ($a in $adapters) {
            try { Set-NetAdapterRss -Name $a.Name -Enabled $true -EA SilentlyContinue } catch {}
            try {
                if (Get-NetAdapterLso -Name $a.Name -EA SilentlyContinue) {
                    Set-NetAdapterLso -Name $a.Name -IPv4Enabled $true -IPv6Enabled $true -EA SilentlyContinue
                }
            } catch {}
            try {
                $imod = Get-NetAdapterAdvancedProperty -Name $a.Name -EA SilentlyContinue | Where-Object { $_.RegistryKeyword -match 'InterruptModeration' }
                if ($imod) { Set-NetAdapterAdvancedProperty -Name $a.Name -RegistryKeyword $imod.RegistryKeyword -RegistryValue 1 -EA SilentlyContinue }
            } catch {}
            try {
                $flow = Get-NetAdapterAdvancedProperty -Name $a.Name -EA SilentlyContinue | Where-Object { $_.RegistryKeyword -match 'FlowControl' }
                if ($flow) { Set-NetAdapterAdvancedProperty -Name $a.Name -RegistryKeyword $flow.RegistryKeyword -RegistryValue 1 -EA SilentlyContinue }
            } catch {}
        }
        Write-Log "NetAdapter restaurado" "padrao"
        [System.Windows.MessageBox]::Show("Adaptadores restaurados para configuracoes padrao!", "Rede", "OK", "Information")
    } catch { [System.Windows.MessageBox]::Show("Erro: $_", "Erro", "OK", "Error") }
}

# ══════════════════════════════════════════════════════════
#  HARDWARE DETALHADO
# ══════════════════════════════════════════════════════════
function Get-DetailedSystemInfo {
    try {
        $OS  = Get-CimInstance Win32_OperatingSystem -EA SilentlyContinue
        $CPU = Get-CimInstance Win32_Processor -EA SilentlyContinue | Select-Object -First 1
        $MB  = Get-CimInstance Win32_BaseBoard -EA SilentlyContinue

        $totalRAMGB = [Math]::Round($OS.TotalVisibleMemorySize / 1MB, 1)
        $freeRAMGB  = [Math]::Round($OS.FreePhysicalMemory  / 1MB, 1)
        $usedRAMGB  = [Math]::Round($totalRAMGB - $freeRAMGB, 1)
        $ramInfo    = "Total: $($totalRAMGB) GB   Usado: $($usedRAMGB) GB   Livre: $($freeRAMGB) GB"

        $ramModules = Get-CimInstance Win32_PhysicalMemory -EA SilentlyContinue
        $slotsUsed  = ($ramModules | Measure-Object).Count
        $totalSlots = 0
        try { $totalSlots = (Get-CimInstance Win32_PhysicalMemoryArray | Select-Object -First 1).MemoryDevices } catch {}
        $ramSlots = "Slots: $slotsUsed usados$(if($totalSlots -gt 0){" de $totalSlots"})"
        $ramDetails = @()
        $sn = 1
        foreach ($m in $ramModules) {
            $capGB  = [Math]::Round($m.Capacity / 1GB, 0)
            $freq   = if ($m.Speed) { "$($m.Speed) MHz" } else { "N/A" }
            $mtype  = switch ($m.MemoryType) { 24 {"DDR3"} 26 {"DDR4"} 34 {"DDR5"} default {"DDR"} }
            $mfr    = if ($m.Manufacturer -and $m.Manufacturer -notmatch "^0{4}") { " ($($m.Manufacturer.Trim()))" } else { "" }
            $ramDetails += "  Slot $($sn): $($capGB) GB $($mtype) @ $($freq)$($mfr)"; $sn++
        }

        $diskLines = @()
        foreach ($pd in (Get-CimInstance Win32_DiskDrive -EA SilentlyContinue)) {
            $sizeGB = [Math]::Round($pd.Size / 1GB, 1)
            $mt = "HDD"
            try {
                $p = Get-PhysicalDisk -EA SilentlyContinue | Where-Object { $_.FriendlyName -eq $pd.Model }
                if ($p -and $p.MediaType -eq 'SSD') { $mt = if ($pd.PNPDeviceID -match 'NVMe|NVME' -or $pd.Model -match 'NVMe|NVME') { "SSD NVMe" } else { "SSD SATA" } }
                elseif ($pd.Model -match 'NVMe|NVME') { $mt = "SSD NVMe" }
            } catch {}
            $diskLines += "  [$($mt)] $($pd.Model.Trim()) - $($sizeGB) GB"
        }

        $partLines = @()
        foreach ($ld in (Get-CimInstance Win32_LogicalDisk -EA SilentlyContinue | Where-Object { $_.DriveType -eq 3 })) {
            $totGB  = [Math]::Round($ld.Size / 1GB, 1)
            $freeGB = [Math]::Round($ld.FreeSpace / 1GB, 1)
            $usedGB = [Math]::Round($totGB - $freeGB, 1)
            $pct    = if ($totGB -gt 0) { [Math]::Round(($usedGB / $totGB) * 100, 0) } else { 0 }
            $partLines += "  Drive $($ld.DeviceID)   $($usedGB) GB / $($totGB) GB   Livre: $($freeGB) GB   ($($pct)%)"
        }

        $gpuLines = @()
        foreach ($g in (Get-CimInstance Win32_VideoController -EA SilentlyContinue)) {
            $vramStr   = if ($g.AdapterRAM -gt 0) { "$([Math]::Round($g.AdapterRAM/1GB,1)) GB VRAM" } else { "" }
            $driverAge = if ($g.DriverDate) { "$([Math]::Round(((Get-Date) - $g.DriverDate).Days / 30, 0)) meses" } else { "N/A" }
            $gpuLines += "  $($g.Name.Trim()) $($vramStr)   Driver: $driverAge"
        }

        $pfInfo = "Gerenciado automaticamente pelo Windows (recomendado)"
        try {
            $pf = Get-CimInstance Win32_PageFileUsage -EA SilentlyContinue
            if ($pf) { $pfInfo = "Alocado: $($pf.AllocatedBaseSize) MB   Em uso: $($pf.CurrentUsage) MB" }
        } catch {}

        $hs = Get-HeuristicScore
        return @"
=======================================================
  SCORE HEURISTICO V5.2   $($hs.Score)/1000 [$($hs.Class)]
=======================================================

$($hs.Recommendations -join "`n")

-------------------------------------------------------
SISTEMA OPERACIONAL
  Nome:         $($OS.Caption)
  Versao:       $($OS.Version)   Build: $($OS.BuildNumber)
  Arquitetura:  $($OS.OSArchitecture)
  Ultimo Boot:  $($OS.LastBootUpTime.ToString('dd/MM/yyyy HH:mm'))

PROCESSADOR
  $($CPU.Name.Trim())
  Nucleos: $($CPU.NumberOfCores)   Threads: $($CPU.NumberOfLogicalProcessors)
  Clock Max: $($CPU.MaxClockSpeed) MHz   Carga: $($CPU.LoadPercentage)%

MEMORIA RAM — $ramInfo
  $ramSlots
$($ramDetails -join "`n")

MEMORIA VIRTUAL (PageFile)
  $pfInfo

DISCOS FISICOS
$($diskLines -join "`n")

PARTICOES
$($partLines -join "`n")

GPU / PLACA DE VIDEO
$($gpuLines -join "`n")

PLACA-MAE
  Fabricante: $(if($MB){$MB.Manufacturer.Trim()}else{"N/A"})   Modelo: $(if($MB){$MB.Product.Trim()}else{"N/A"})
"@
    } catch { return "Erro ao carregar informacoes: $_" }
}

# ══════════════════════════════════════════════════════════
#  MODO GAMER V5.2 — TEXTO CAUTELOSO
# ══════════════════════════════════════════════════════════
function Toggle-GamerMode {
    param([System.Windows.Controls.Label]$StatusLabel, [System.Windows.Controls.Button]$Btn)
    $taskName = "WindowsOptimizerPro_GamerMode"
    try {
        $isActive = (Get-ItemProperty $Global:RegPath -Name GamerModeActive -EA SilentlyContinue).GamerModeActive -eq 1
        if (-not $isActive) {
            # Criar ponto de restauracao ANTES
            New-SafeRestorePoint "Antes Gamer Mode V5.2" | Out-Null
            Backup-RegistryKey "HKCU:\SOFTWARE\Microsoft\GameBar" "gamermode" | Out-Null
            Backup-RegistryKey "HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" "hwsched" | Out-Null

            New-ItemProperty "HKCU:\SOFTWARE\Microsoft\GameBar"  -Name "AllowAutoGameMode"  -Value 1 -PropertyType DWORD -Force | Out-Null
            New-ItemProperty "HKCU:\SOFTWARE\Microsoft\GameBar"  -Name "AutoGameModeEnabled" -Value 1 -PropertyType DWORD -Force | Out-Null
            New-ItemProperty "HKCU:\System\GameConfigStore"      -Name "GameDVR_Enabled"     -Value 0 -PropertyType DWORD -Force | Out-Null
            New-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" -Name "HwSchMode" -Value 2 -PropertyType DWORD -Force | Out-Null
            New-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" -Name "SystemResponsiveness" -Value 0 -PropertyType DWORD -Force | Out-Null
            New-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" -Name "Priority" -Value 6 -PropertyType DWORD -Force -EA SilentlyContinue | Out-Null
            New-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" -Name "Scheduling Category" -Value "High" -Force -EA SilentlyContinue | Out-Null
            Get-ChildItem "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces" -EA SilentlyContinue | ForEach-Object {
                New-ItemProperty $_.PSPath -Name "TcpAckFrequency" -Value 1 -PropertyType DWORD -Force -EA SilentlyContinue | Out-Null
                New-ItemProperty $_.PSPath -Name "TCPNoDelay"      -Value 1 -PropertyType DWORD -Force -EA SilentlyContinue | Out-Null
            }
            $enc = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes('New-ItemProperty "HKCU:\SOFTWARE\Microsoft\GameBar" -Name AllowAutoGameMode -Value 1 -PropertyType DWORD -Force | Out-Null'))
            Register-ScheduledTask -TaskName $taskName -Action (New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -WindowStyle Hidden -EncodedCommand $enc") -Trigger (New-ScheduledTaskTrigger -AtLogOn) -Settings (New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -RunOnlyIfNetworkAvailable:$false) -RunLevel Highest -Force -EA SilentlyContinue | Out-Null
            New-Item $Global:RegPath -Force -EA SilentlyContinue | Out-Null
            New-ItemProperty $Global:RegPath -Name "GamerModeActive" -Value 1 -PropertyType DWORD -Force | Out-Null
            $StatusLabel.Content = "ATIVADO"
            $StatusLabel.Foreground = [System.Windows.Media.Brushes]::Lime
            $Btn.Background = [System.Windows.Media.BrushConverter]::new().ConvertFrom("#DC3545")
            $Btn.Content = "DESATIVAR MODO GAMER"
            $Global:GamerModeActive = $true
            Write-Log "GamerMode ativado" "OK"
        } else {
            New-ItemProperty "HKCU:\SOFTWARE\Microsoft\GameBar" -Name "AllowAutoGameMode"  -Value 0 -PropertyType DWORD -Force | Out-Null
            New-ItemProperty "HKCU:\SOFTWARE\Microsoft\GameBar" -Name "AutoGameModeEnabled" -Value 0 -PropertyType DWORD -Force | Out-Null
            New-ItemProperty "HKCU:\System\GameConfigStore"     -Name "GameDVR_Enabled"     -Value 1 -PropertyType DWORD -Force | Out-Null
            New-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" -Name "HwSchMode" -Value 1 -PropertyType DWORD -Force -EA SilentlyContinue | Out-Null
            New-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" -Name "SystemResponsiveness" -Value 20 -PropertyType DWORD -Force -EA SilentlyContinue | Out-Null
            Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -EA SilentlyContinue
            New-ItemProperty $Global:RegPath -Name "GamerModeActive" -Value 0 -PropertyType DWORD -Force -EA SilentlyContinue | Out-Null
            $StatusLabel.Content = "DESATIVADO"
            $StatusLabel.Foreground = [System.Windows.Media.Brushes]::Red
            $Btn.Background = [System.Windows.Media.BrushConverter]::new().ConvertFrom("#28A745")
            $Btn.Content = "ATIVAR MODO GAMER"
            $Global:GamerModeActive = $false
            Write-Log "GamerMode desativado" "OK"
        }
    } catch { [System.Windows.MessageBox]::Show("Erro: $($_.Exception.Message)", "Erro", "OK", "Error") }
}

# ══════════════════════════════════════════════════════════
#  LIMPEZA
# ══════════════════════════════════════════════════════════
function Invoke-DeepClean {
    $freed = 0
    $paths = @(
        "$env:TEMP\*", "$env:SystemRoot\Temp\*",
        "$env:SystemRoot\SoftwareDistribution\Download\*",
        "$env:SystemRoot\SoftwareDistribution\DataStore\Logs\*",
        "$env:SystemRoot\Prefetch\*",
        "$env:LOCALAPPDATA\Microsoft\Windows\INetCache\*",
        "$env:LOCALAPPDATA\CrashDumps\*", "$env:SystemRoot\Minidump\*",
        "$env:LOCALAPPDATA\Microsoft\Windows\WER\*",
        "$env:ProgramData\Microsoft\Windows\WER\*",
        "$env:SystemRoot\Logs\CBS\*",
        "$env:SystemDrive\`$Recycle.Bin\*"
    )
    foreach ($p in $paths) {
        try {
            $s = (Get-ChildItem $p -Recurse -Force -EA SilentlyContinue | Measure-Object Length -Sum).Sum
            Remove-Item $p -Recurse -Force -EA SilentlyContinue
            $freed += $s
        } catch {}
    }
    ipconfig /flushdns | Out-Null
    $mb = [Math]::Round($freed / 1MB, 2)
    $Global:SpaceFreed += $freed
    Write-Log "DeepClean" "$mb MB liberados"
    [System.Windows.MessageBox]::Show("Limpeza Profunda concluida!`nLiberado: $($mb) MB`n`nTemp, Prefetch, SoftwareDistribution,`nWER Dumps, Cache, Lixeira, DNS.", "Limpeza OK", "OK", "Information")
}

function Invoke-PostUpdateClean {
    $freed = 0
    foreach ($p in @(
        "$env:SystemRoot\SoftwareDistribution\Download\*",
        "$env:SystemRoot\SoftwareDistribution\DataStore\Logs\*",
        "$env:SystemRoot\Logs\CBS\*", "$env:SystemRoot\Logs\DISM\*",
        "$env:SystemRoot\Temp\*", "$env:TEMP\*"
    )) { try { $s=(Get-ChildItem $p -Recurse -Force -EA SilentlyContinue|Measure-Object Length -Sum).Sum; Remove-Item $p -Recurse -Force -EA SilentlyContinue; $freed+=$s } catch {} }
    try { dism /online /cleanup-image /startcomponentcleanup 2>$null | Out-Null } catch {}
    $mb = [Math]::Round($freed/1MB,2); $Global:SpaceFreed += $freed
    Write-Log "PostUpdateClean" "$mb MB"
    [System.Windows.MessageBox]::Show("Limpeza Pos-Update concluida!`nLiberado: $($mb) MB", "Pos-Update", "OK", "Information")
}

function Clean-BrowserCache { param([string]$Browser)
    $freed = 0
    $paths = switch ($Browser) {
        'Edge'    { @("$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default\Cache", "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default\Code Cache", "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default\GPUCache") }
        'Chrome'  { @("$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Cache", "$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Code Cache", "$env:LOCALAPPDATA\Google\Chrome\User Data\Default\GPUCache") }
        'Firefox' { $p=Get-ChildItem "$env:APPDATA\Mozilla\Firefox\Profiles" -EA SilentlyContinue; $p | ForEach-Object { "$($_.FullName)\cache2\entries", "$($_.FullName)\startupCache" } }
        'Brave'   { @("$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data\Default\Cache", "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data\Default\Code Cache") }
    }
    foreach ($path in $paths) {
        if (Test-Path $path) {
            try { $s=(Get-ChildItem $path -Recurse -EA SilentlyContinue|Measure-Object Length -Sum).Sum; Remove-Item "$path\*" -Recurse -Force -EA SilentlyContinue; $freed+=$s } catch {}
        }
    }
    $mb=[Math]::Round($freed/1MB,2); $Global:SpaceFreed+=$freed
    Write-Log "BrowserCache $Browser" "$mb MB"
    [System.Windows.MessageBox]::Show("Cache $Browser limpo!`nLiberado: $($mb) MB","OK","OK","Information")
}

# ══════════════════════════════════════════════════════════
#  EDGE DEEP CLEAN (V5.2) — Para o Edge e limpa caches reais
# ══════════════════════════════════════════════════════════
function Invoke-EdgeDeepClean {
    try {
        Write-Log "Edge Deep Clean iniciado"
        # Fechar Edge antes de limpar (necessario para liberar lock nos arquivos)
        Get-Process -Name "msedge" -EA SilentlyContinue | Stop-Process -Force -EA SilentlyContinue
        Start-Sleep -Milliseconds 800

        $edgePath = "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default"
        if (-not (Test-Path $edgePath)) {
            [System.Windows.MessageBox]::Show("Microsoft Edge nao encontrado neste perfil de usuario.", "Edge", "OK", "Warning")
            return
        }

        $freed   = 0
        $cleaned = @()
        # Todos os diretórios de cache/lixo — dados pessoais (senhas, favoritos, historico) NAO sao tocados
        $targets = @(
            "Cache",
            "Code Cache",
            "GPUCache",
            "ShaderCache",
            "Storage\next-gen",
            "Service Worker\CacheStorage",
            "Service Worker\ScriptCache",
            "WebStorage"
        )

        foreach ($folder in $targets) {
            $path = Join-Path $edgePath $folder
            if (Test-Path $path) {
                $sz = 0
                try { $sz = (Get-ChildItem $path -Recurse -Force -EA SilentlyContinue | Measure-Object Length -Sum).Sum } catch {}
                Get-ChildItem -Path $path -Recurse -Force -EA SilentlyContinue | Remove-Item -Force -Recurse -EA SilentlyContinue
                $freed   += $sz
                $cleaned += "+ Limpo: $folder  ($([Math]::Round($sz/1MB,1)) MB)"
            }
        }

        $mb = [Math]::Round($freed / 1MB, 2)
        $Global:SpaceFreed += $freed
        Write-Log "Edge Deep Clean concluido: $mb MB liberados"
        [System.Windows.MessageBox]::Show(
            "Limpeza Profunda do Edge concluida!`n`n$($cleaned -join "`n")`n`nTotal liberado: $($mb) MB`n`nDados pessoais (senhas, favoritos, historico) nao foram tocados.",
            "Edge Deep Clean", "OK", "Information"
        )
    } catch {
        Write-Log "Erro Edge Deep Clean: $_"
        [System.Windows.MessageBox]::Show("Erro ao limpar Edge: $_", "Erro", "OK", "Error")
    }
}

# ══════════════════════════════════════════════════════════
#  SSD TRIM AVANCADO (V5.2) — Usa Get-Volume (mais robusto)
# ══════════════════════════════════════════════════════════
function Invoke-SSDTrimAdvanced {
    try {
        Write-Log "SSD TRIM Avancado iniciado"
        # Get-Volume identifica automaticamente todos os volumes fixos
        $volumes = Get-Volume -EA SilentlyContinue | Where-Object {
            $_.DriveType -eq 'Fixed' -and $null -ne $_.DriveLetter
        }
        if (-not $volumes) {
            [System.Windows.MessageBox]::Show("Nenhum volume fixo encontrado.", "TRIM", "OK", "Warning")
            return
        }
        $done = @()
        foreach ($vol in $volumes) {
            try {
                Optimize-Volume -DriveLetter $vol.DriveLetter -ReTrim -EA SilentlyContinue
                $label = if ($vol.FileSystemLabel) { " [$($vol.FileSystemLabel)]" } else { "" }
                $done += "+ TRIM enviado: $($vol.DriveLetter):$label"
            } catch {
                $done += "- Falha em $($vol.DriveLetter): $_"
            }
        }
        Write-Log "SSD TRIM Avancado concluido: $($volumes.Count) volumes"
        [System.Windows.MessageBox]::Show(
            "Otimizacao SSD (TRIM Avancado) concluida!`n`n$($done -join "`n")`n`nNOTA: TRIM enviado a todos os volumes fixos (mais abrangente que o TRIM basico).",
            "TRIM Avancado", "OK", "Information"
        )
    } catch {
        Write-Log "Erro SSD TRIM Avancado: $_"
        [System.Windows.MessageBox]::Show("Erro: $_", "Erro", "OK", "Error")
    }
}

function Invoke-WindowsDiskCleanup {
    try {
        $sageset = 65535
        $base    = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches"
        @('Active Setup Temp Folders','D3D Shader Cache','Delivery Optimization Files','Downloaded Program Files',
          'Internet Cache Files','Old ChkDsk Files','Recycle Bin','Setup Log Files','System error memory dump files',
          'System error minidump files','Temporary Files','Temporary Setup Files','Thumbnail Cache','Update Cleanup',
          'Windows Error Reporting Archive Files','Windows Error Reporting Queue Files','Windows Upgrade Log Files') | ForEach-Object {
            if (Test-Path "$base\$_") { New-ItemProperty "$base\$_" -Name "StateFlags$sageset" -Value 2 -PropertyType DWORD -Force -EA SilentlyContinue | Out-Null }
        }
        [System.Windows.MessageBox]::Show("Limpeza de Disco sera aberta com todas as categorias.", "Limpeza de Disco", "OK", "Information")
        Start-Process "cleanmgr.exe" -ArgumentList "/sagerun:$sageset" -Verb RunAs -EA SilentlyContinue
    } catch { Start-Process "cleanmgr.exe" -Verb RunAs -EA SilentlyContinue }
}

function Invoke-WingetUpgrade { param([bool]$ListOnly=$false)
    if (-not (Get-Command winget -EA SilentlyContinue)) {
        [System.Windows.MessageBox]::Show("Winget nao encontrado. Instale via Microsoft Store: 'App Installer'","Winget","OK","Warning"); return
    }
    if ($ListOnly) {
        Start-Process "cmd.exe" -ArgumentList "/k winget upgrade && pause" -Verb RunAs
    } else {
        if ([System.Windows.MessageBox]::Show("Atualizar todos os apps via Winget?","Winget","YesNo","Question") -eq "Yes") {
            Start-Process "cmd.exe" -ArgumentList "/k winget upgrade --all --accept-source-agreements --accept-package-agreements && pause" -Verb RunAs
        }
    }
}

function Clean-DirectX {
    $freed=0
    @("$env:LOCALAPPDATA\D3DSCache","$env:APPDATA\Microsoft\Windows\D3DSCache","$env:LOCALAPPDATA\NVIDIA\DXCache") | ForEach-Object {
        if(Test-Path $_){ try{$s=(Get-ChildItem $_ -Recurse -EA SilentlyContinue|Measure-Object Length -Sum).Sum;Remove-Item "$_\*" -Recurse -Force -EA SilentlyContinue;$freed+=$s}catch{} }
    }
    $mb=[Math]::Round($freed/1MB,2); $Global:SpaceFreed+=$freed
    [System.Windows.MessageBox]::Show("Cache DirectX limpo!`nLiberado: $($mb) MB","DirectX","OK","Information")
}

function Clean-GPUCache { param([string]$GPU)
    $freed=0
    $paths=switch($GPU){
        'NVIDIA'{@("$env:LOCALAPPDATA\NVIDIA\DXCache","$env:LOCALAPPDATA\NVIDIA\GLCache","$env:APPDATA\NVIDIA\ComputeCache")}
        'AMD'   {@("$env:LOCALAPPDATA\AMD","$env:APPDATA\AMD","$env:TEMP\AMD")}
        'Intel' {@("$env:LOCALAPPDATA\Intel\ShaderCache","$env:APPDATA\Intel\ShaderCache")}
    }
    foreach($p in $paths){ if(Test-Path $p){ try{$s=(Get-ChildItem "$p\*" -Recurse -EA SilentlyContinue|Measure-Object Length -Sum).Sum;Remove-Item "$p\*" -Recurse -Force -EA SilentlyContinue;$freed+=$s}catch{} } }
    $mb=[Math]::Round($freed/1MB,2); $Global:SpaceFreed+=$freed
    [System.Windows.MessageBox]::Show("Cache $GPU limpo!`nLiberado: $($mb) MB","GPU Cache","OK","Information")
}

function Optimize-Disk { param([bool]$IsSSD)
    $msg=""
    foreach($d in (Get-CimInstance Win32_LogicalDisk -EA SilentlyContinue | Where-Object{$_.DriveType -eq 3})){
        $l=$d.DeviceID.TrimEnd(':')
        try{
            if($IsSSD){ Optimize-Volume -DriveLetter $l -ReTrim -EA SilentlyContinue; $msg+="TRIM $($d.DeviceID) OK`n" }
            else       { Optimize-Volume -DriveLetter $l -Defrag -EA SilentlyContinue; $msg+="Defrag $($d.DeviceID) OK`n" }
        } catch { $msg+="Falha $($d.DeviceID)`n" }
    }
    [System.Windows.MessageBox]::Show("Concluido!`n$msg","Disco","OK","Information")
}

function Get-NetworkAIAnalysis {
    try {
        $lines=@()
        foreach($a in (Get-NetAdapter | Where-Object{$_.Status -eq 'Up'})){
            $cfg=Get-NetIPAddress -InterfaceIndex $a.ifIndex -AddressFamily IPv4 -EA SilentlyContinue|Select-Object -First 1
            $spd="N/A"
            try{
                $raw=[string]$a.ReceiveLinkSpeed
                if($raw -match "Gbps|Mbps"){ $spd=$raw }
                else { $b=[double]$raw; $spd=if($b -ge 1e9){"$([Math]::Round($b/1e9,1)) Gbps"}else{"$([Math]::Round($b/1e6,0)) Mbps"} }
            } catch { try{ $spd=[string]$a.LinkSpeed }catch{ $spd="N/A" } }
            $ip=if($cfg.IPAddress){$cfg.IPAddress}else{"Sem IP"}
            $lines+="  $($a.Name.PadRight(20)) $($spd.PadRight(12)) IP: $ip"
        }
        $dns=@()
        (Get-DnsClientServerAddress -AddressFamily IPv4 -EA SilentlyContinue|Where-Object{$_.ServerAddresses})|ForEach-Object{
            $dns+="  $($_.InterfaceAlias): $($_.ServerAddresses -join ', ')"
        }
        $lG=999;$lC=999;$lO=999
        try{$r=Test-Connection 8.8.8.8 -Count 2 -EA SilentlyContinue;if($r){$lG=[Math]::Round(($r|Measure-Object ResponseTime -Average).Average,1)}}catch{}
        try{$r=Test-Connection 1.1.1.1 -Count 2 -EA SilentlyContinue;if($r){$lC=[Math]::Round(($r|Measure-Object ResponseTime -Average).Average,1)}}catch{}
        try{$r=Test-Connection 208.67.222.222 -Count 2 -EA SilentlyContinue;if($r){$lO=[Math]::Round(($r|Measure-Object ResponseTime -Average).Average,1)}}catch{}
        $mn=[Math]::Min($lG,[Math]::Min($lC,$lO))
        $best=if($mn -eq $lC){"Cloudflare 1.1.1.1"}elseif($mn -eq $lO){"OpenDNS 208.67.222.222"}else{"Google 8.8.8.8"}
        return @"
=======================================================
  ANALISE HEURISTICA DE REDE
=======================================================
ADAPTADORES:
$($lines -join "`n")

DNS CONFIGURADO:
$(if($dns){$dns -join "`n"}else{"  N/A"})

BENCHMARK DNS:
  Google      8.8.8.8         $(if($lG -eq 999){"Timeout"}else{"$($lG) ms"})
  Cloudflare  1.1.1.1         $(if($lC -eq 999){"Timeout"}else{"$($lC) ms"})
  OpenDNS     208.67.222.222  $(if($lO -eq 999){"Timeout"}else{"$($lO) ms"})

  Recomendado: $best
=======================================================
"@
    } catch { return "Clique em 'Atualizar Analise de Rede'." }
}

function Set-BestDNS { param([string]$DNS)
    Backup-RegistryKey "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" "dns" | Out-Null
    $s=switch($DNS){'Google'{@("8.8.8.8","8.8.4.4")}'Cloudflare'{@("1.1.1.1","1.0.0.1")}'OpenDNS'{@("208.67.222.222","208.67.220.220")}}
    Get-NetAdapter|Where-Object{$_.Status -eq 'Up'}|ForEach-Object{try{Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ServerAddresses $s -EA SilentlyContinue}catch{}}
    ipconfig /flushdns|Out-Null
    Write-Log "DNS alterado" $DNS
    [System.Windows.MessageBox]::Show("DNS alterado para $DNS!`n$($s -join ', ')","DNS","OK","Information")
}

function Restore-DNS {
    $res = [System.Windows.MessageBox]::Show("Restaurar DNS para obtencao automatica (DHCP)?", "Restaurar DNS", "YesNo", "Question")
    if ($res -ne "Yes") { return }
    Get-NetAdapter | Where-Object {$_.Status -eq 'Up'} | ForEach-Object {
        try { Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ResetServerAddresses -EA SilentlyContinue } catch {}
    }
    ipconfig /flushdns | Out-Null
    Write-Log "DNS restaurado" "DHCP automatico"
    [System.Windows.MessageBox]::Show("DNS restaurado para obtencao automatica!", "DNS", "OK", "Information")
}

function Optimize-TCPNetwork {
    try {
        Backup-RegistryKey "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" "multimedia" | Out-Null
        netsh int tcp set global autotuninglevel=normal 2>$null|Out-Null
        netsh int tcp set global rss=enabled 2>$null|Out-Null
        netsh int tcp set global ecncapability=enabled 2>$null|Out-Null
        netsh int tcp set global timestamps=disabled 2>$null|Out-Null
        New-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" -Name "NetworkThrottlingIndex" -Value 0xffffffff -PropertyType DWORD -Force|Out-Null
        Get-ChildItem "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces" -EA SilentlyContinue|ForEach-Object{
            New-ItemProperty $_.PSPath -Name "TcpAckFrequency" -Value 1 -PropertyType DWORD -Force -EA SilentlyContinue|Out-Null
            New-ItemProperty $_.PSPath -Name "TCPNoDelay"      -Value 1 -PropertyType DWORD -Force -EA SilentlyContinue|Out-Null
        }
        Write-Log "TCPOptimize" "OK"
        [System.Windows.MessageBox]::Show("Otimizacao TCP aplicada!`n+ AutoTuning Normal`n+ RSS ON`n+ ECN ON`n+ Nagle OFF","TCP","OK","Information")
    } catch { [System.Windows.MessageBox]::Show("Erro: $_","Erro","OK","Error") }
}

function Repair-NetworkFull {
    try {
        ipconfig /flushdns 2>$null|Out-Null; ipconfig /release 2>$null|Out-Null; ipconfig /renew 2>$null|Out-Null
        netsh winsock reset 2>$null|Out-Null; netsh int ip reset 2>$null|Out-Null
        Write-Log "NetworkFull" "Correcao completa"
        [System.Windows.MessageBox]::Show("Correcao completa aplicada!`nReinicie o PC.","Rede","OK","Warning")
    } catch { [System.Windows.MessageBox]::Show("Erro: $_","Erro","OK","Error") }
}

function Start-ExternalRepair { param([string]$Type)
    $cmd=switch($Type){
        'DISM_SCAN'  {'echo === DISM Verificar === && Dism /Online /Cleanup-Image /CheckHealth && Dism /Online /Cleanup-Image /ScanHealth && pause'}
        'DISM_REPAIR'{'echo === DISM Reparar === && Dism /Online /Cleanup-Image /RestoreHealth && pause'}
        'SFC'        {'echo === SFC === && sfc /scannow && pause'}
        'FULL_REPAIR'{'echo === REPARO COMPLETO === && Dism /Online /Cleanup-Image /RestoreHealth && sfc /scannow && pause'}
    }
    Start-Process "cmd.exe" -ArgumentList "/k $cmd" -Verb RunAs
}

function Disable-Telemetry {
    Backup-RegistryKey "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection" "telemetria" | Out-Null
    try {
        New-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection" -Name "AllowTelemetry" -Value 0 -PropertyType DWORD -Force|Out-Null
        Stop-Service DiagTrack -Force -EA SilentlyContinue; Set-Service DiagTrack -StartupType Disabled -EA SilentlyContinue
        Stop-Service dmwappushservice -Force -EA SilentlyContinue; Set-Service dmwappushservice -StartupType Disabled -EA SilentlyContinue
        @('Microsoft Compatibility Appraiser','ProgramDataUpdater','Consolidator','UsbCeip')|ForEach-Object{Disable-ScheduledTask -TaskName $_ -EA SilentlyContinue|Out-Null}
        Write-Log "Telemetria desabilitada" "OK"
        [System.Windows.MessageBox]::Show("Telemetria desabilitada!`n+ DiagTrack OFF`n+ dmwappushservice OFF`n+ Tarefas OFF","Telemetria OFF","OK","Information")
    } catch { [System.Windows.MessageBox]::Show("Erro: $($_.Exception.Message)","Erro","OK","Error") }
}

function Enable-Telemetry {
    $res = [System.Windows.MessageBox]::Show("Reativar Telemetria do Windows?`n(Restaura configuracao padrao Microsoft)", "Reativar Telemetria", "YesNo", "Question")
    if ($res -ne "Yes") { return }
    try {
        Remove-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection" -Name "AllowTelemetry" -EA SilentlyContinue
        Set-Service DiagTrack -StartupType Automatic -EA SilentlyContinue; Start-Service DiagTrack -EA SilentlyContinue
        Set-Service dmwappushservice -StartupType Automatic -EA SilentlyContinue; Start-Service dmwappushservice -EA SilentlyContinue
        Write-Log "Telemetria reativada" "padrao"
        [System.Windows.MessageBox]::Show("Telemetria reativada (padrao Microsoft).","Telemetria ON","OK","Information")
    } catch { [System.Windows.MessageBox]::Show("Erro: $_","Erro","OK","Error") }
}

function New-RestorePoint {
    New-SafeRestorePoint "WinOptimizer Pro V5.2 - $(Get-Date -Format 'dd/MM/yyyy HH:mm')" | Out-Null
    [System.Windows.MessageBox]::Show("Ponto de Restauracao criado!`n$(Get-Date -Format 'dd/MM/yyyy HH:mm')","Restauracao","OK","Information")
}

function Invoke-HeuristicOptimize {
    try {
        $before = Get-HeuristicScore
        $done   = @()
        $OS     = Get-CimInstance Win32_OperatingSystem -EA SilentlyContinue
        $ramPct = [Math]::Round((($OS.TotalVisibleMemorySize - $OS.FreePhysicalMemory) / $OS.TotalVisibleMemorySize) * 100, 0)
        if ($ramPct -gt 70) {
            Backup-RegistryKey "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" "visualfx" | Out-Null
            New-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" -Name "VisualFXSetting" -Value 2 -PropertyType DWORD -Force -EA SilentlyContinue|Out-Null
            $done += "+ Visual Effects: Performance (RAM alta)"
        }
        @('DiagTrack','SysMain') | ForEach-Object {
            $svc = Get-Service $_ -EA SilentlyContinue
            if ($svc -and $svc.Status -eq 'Running') {
                Stop-Service $_ -Force -EA SilentlyContinue
                Set-Service  $_ -StartupType Disabled -EA SilentlyContinue
                $done += "+ Servico '$_' otimizado"
            }
        }
        fsutil behavior set disablelastaccess 1 2>$null|Out-Null; $done += "+ NTFS LastAccess OFF"
        New-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters" -Name "EnablePrefetcher" -Value 3 -PropertyType DWORD -Force -EA SilentlyContinue|Out-Null
        $done += "+ Prefetch otimizado"
        New-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" -Name "ClearPageFileAtShutdown" -Value 0 -PropertyType DWORD -Force -EA SilentlyContinue|Out-Null
        $done += "+ PageFile: limpeza no shutdown OFF"
        New-ItemProperty "HKCU:\Control Panel\Desktop" -Name "MenuShowDelay" -Value "0" -PropertyType String -Force -EA SilentlyContinue|Out-Null
        $done += "+ Menu delay: 0ms"
        $done += "+ Plano de energia: mantido padrao Windows (nao alterado)"
        $after = Get-HeuristicScore
        Save-ScoreHistory -Score $after.Score -Class $after.Class
        Write-Log "HeuristicOptimize" "Antes=$($before.Score) Depois=$($after.Score)"
        [System.Windows.MessageBox]::Show("Otimizacao Heuristica V5.2 Concluida!`n`nScore antes: $($before.Score)/1000`nScore depois: $($after.Score)/1000`n`n$($done -join "`n")","Score Otimizacao","OK","Information")
    } catch { [System.Windows.MessageBox]::Show("Erro: $_","Erro","OK","Error") }
}

function Invoke-RAMClean {
    try {
        $OS     = Get-CimInstance Win32_OperatingSystem -EA SilentlyContinue
        $ramPct = [Math]::Round((($OS.TotalVisibleMemorySize - $OS.FreePhysicalMemory) / $OS.TotalVisibleMemorySize) * 100, 0)
        # Aviso se RAM livre < 20%
        if ($ramPct -gt 80) {
            $warn = [System.Windows.MessageBox]::Show("RAM esta com $ramPct% de uso (acima de 80%).`nA limpeza pode causar swapping temporario.`nContinuar mesmo assim?", "Aviso RAM", "YesNo", "Warning")
            if ($warn -ne "Yes") { return }
        }
        $before=[Math]::Round($OS.FreePhysicalMemory/1MB,1)
        $ct=0; Get-Process -EA SilentlyContinue|ForEach-Object{try{[MemoryHelper]::EmptyWorkingSet($_.Handle)|Out-Null;$ct++}catch{}}
        [System.GC]::Collect(); [System.GC]::WaitForPendingFinalizers(); Start-Sleep -Milliseconds 500
        $after=[Math]::Round((Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory/1MB,1)
        $gained=[Math]::Round($after-$before,1)
        Write-Log "RAMClean" "+$gained GB liberados"
        [System.Windows.MessageBox]::Show("RAM limpa!`n`nAntes:  $($before) GB livre`nDepois: $($after) GB livre`n$(if($gained -gt 0){"+$gained GB liberados"}else{"Ja estava otimizado"})`nProcessos: $ct","RAM Cleaner","OK","Information")
    } catch { [System.Windows.MessageBox]::Show("Erro: $_","Erro","OK","Error") }
}

function Get-CriticalErrors {
    try {
        $ev=Get-EventLog -LogName System -EntryType Error,Warning -Newest 15 -EA SilentlyContinue
        if(-not $ev){return "Nenhum erro critico encontrado."}
        $lines=@("Ultimos 15 eventos criticos:","")
        foreach($e in $ev){
            $t=if($e.EntryType -eq 'Error'){"[ERRO] "}else{"[AVIS] "}
            $m=$e.Message.Split("`n")[0].Trim(); if($m.Length -gt 70){$m=$m.Substring(0,70)+"..."}
            $lines+="$t $($e.TimeGenerated.ToString('dd/MM HH:mm'))  $($e.Source.PadRight(20))  $m"
        }
        return $lines -join "`n"
    } catch { return "Nao foi possivel ler Event Log." }
}

function Invoke-AutoSchedule {
    $tn="WindowsOptimizerPro_WeeklyClean"
    if(Get-ScheduledTask -TaskName $tn -EA SilentlyContinue){
        $r=[System.Windows.MessageBox]::Show("Limpeza semanal ja configurada. Remover?","Auto","YesNo","Question")
        if($r -eq "Yes"){Unregister-ScheduledTask -TaskName $tn -Confirm:$false -EA SilentlyContinue;[System.Windows.MessageBox]::Show("Agenda removida.","OK","OK","Information")}
        return
    }
    $act=New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -WindowStyle Hidden -Command `"Remove-Item `$env:TEMP\* -Recurse -Force -EA SilentlyContinue; ipconfig /flushdns`""
    Register-ScheduledTask -TaskName $tn -Action $act -Trigger (New-ScheduledTaskTrigger -Weekly -DaysOfWeek Sunday -At "03:00AM") -Settings (New-ScheduledTaskSettingsSet -StopIfGoingOffBatteries:$false) -RunLevel Highest -Force -EA SilentlyContinue|Out-Null
    [System.Windows.MessageBox]::Show("Limpeza agendada!`nTodo Domingo 03:00 — Temp + DNS","Agendado","OK","Information")
}

function Export-Report {
    try {
        $path="$env:USERPROFILE\Desktop\WinOptimizer_Report_$(Get-Date -Format 'yyyyMMdd_HHmm').txt"
        $hs=Get-HeuristicScore; $hist=Get-ScoreHistory
        $content=@"
==========================================================================
  WINDOWS OPTIMIZER PRO V5.2 — RELATORIO COMPLETO
  Data: $(Get-Date -Format 'dd/MM/yyyy HH:mm:ss')
==========================================================================

$(Get-DetailedSystemInfo)

==========================================================================
  ANALISE DE REDE
==========================================================================
$(Get-NetworkAIAnalysis)

==========================================================================
  HISTORICO DE SCORES
==========================================================================
$(if($hist){$hist -join "`n"}else{"Sem historico registrado."})

==========================================================================
  ERROS CRITICOS RECENTES
==========================================================================
$(Get-CriticalErrors)

==========================================================================
  LOG DE ACOES
==========================================================================
$(if(Test-Path $Global:LogFile){Get-Content $Global:LogFile -Tail 50}else{"Sem log registrado."})
==========================================================================
  FIM DO RELATORIO
==========================================================================
"@
        $content|Out-File -FilePath $path -Encoding UTF8
        Write-Log "ExportReport" $path
        [System.Windows.MessageBox]::Show("Relatorio exportado!`n$path","Relatorio","OK","Information")
    } catch { [System.Windows.MessageBox]::Show("Erro: $_","Erro","OK","Error") }
}

function Get-GamerModeState {
    return ((Get-ItemProperty $Global:RegPath -Name GamerModeActive -EA SilentlyContinue).GamerModeActive -eq 1)
}

function Show-StartupManager {
    $items=@()
    @('HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run','HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run')|ForEach-Object{
        $p=Get-ItemProperty $_ -EA SilentlyContinue
        if($p){$p.PSObject.Properties|Where-Object{$_.Name -notmatch '^PS'}|ForEach-Object{$items+=[PSCustomObject]@{Name=$_.Name;Source=$_ -replace '.*\\',''}}}
    }
    if($items.Count -eq 0){[System.Windows.MessageBox]::Show("Nenhum app de inicializacao encontrado.","Startup","OK","Information");return}
    $list=$items|ForEach-Object{"  $($_.Name.PadRight(38)) [$($_.Source)]"}
    $r=[System.Windows.MessageBox]::Show("STARTUP APPS ($($items.Count)):`n`n$($list -join "`n")`n`nAbrir Gerenciador de Tarefas?","Startup Manager","YesNo","Information")
    if($r -eq "Yes"){Start-Process "taskmgr.exe" -ArgumentList "/7" -EA SilentlyContinue}
}

# ══════════════════════════════════════════════════════════
#  INTERFACE XAML V5.2 — MELHORADA
# ══════════════════════════════════════════════════════════
[xml]$XAML = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Windows Optimizer Pro V5.2 ULTRA PRO"
        Height="980" Width="1400" MinHeight="820" MinWidth="1200"
        WindowStartupLocation="CenterScreen" Background="#080C14" ResizeMode="CanResize">
  <Window.Resources>

    <!-- ESTILO GLOBAL BUTTON -->
    <Style TargetType="Button">
      <Setter Property="FontFamily" Value="Segoe UI"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="FontSize" Value="13"/>
      <Setter Property="BorderThickness" Value="0"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Padding" Value="14,8"/>
      <Setter Property="Margin" Value="0,3"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border x:Name="bd" Background="{TemplateBinding Background}" CornerRadius="10" Padding="{TemplateBinding Padding}">
              <Border.Effect><DropShadowEffect Color="#000000" BlurRadius="8" ShadowDepth="2" Opacity="0.25"/></Border.Effect>
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="bd" Property="Opacity" Value="0.82"/></Trigger>
              <Trigger Property="IsPressed"   Value="True"><Setter TargetName="bd" Property="Opacity" Value="0.60"/></Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <!-- ESTILO TABITEM -->
    <Style TargetType="TabItem">
      <Setter Property="Foreground" Value="#7A8FAA"/>
      <Setter Property="FontFamily" Value="Segoe UI"/>
      <Setter Property="FontSize" Value="13"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="Padding" Value="20,11"/>
      <Setter Property="BorderThickness" Value="0"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="TabItem">
            <Border x:Name="tb" Background="Transparent" Padding="20,11" Margin="1,0">
              <ContentPresenter ContentSource="Header" HorizontalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsSelected" Value="True">
                <Setter TargetName="tb" Property="Background" Value="#0C1F3A"/>
                <Setter Property="Foreground" Value="#00D9FF"/>
              </Trigger>
              <Trigger Property="IsMouseOver" Value="True">
                <Setter TargetName="tb" Property="Background" Value="#101C2E"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <!-- ESTILO COMBOBOX -->
    <Style TargetType="ComboBox">
      <Setter Property="FontFamily" Value="Segoe UI"/><Setter Property="FontSize" Value="13"/>
      <Setter Property="Background" Value="#142030"/><Setter Property="Foreground" Value="#D0E4F4"/>
      <Setter Property="BorderBrush" Value="#243A55"/><Setter Property="BorderThickness" Value="1"/>
      <Setter Property="Padding" Value="8,6"/>
    </Style>
    <Style TargetType="ComboBoxItem">
      <Setter Property="FontFamily" Value="Segoe UI"/><Setter Property="FontSize" Value="13"/>
      <Setter Property="Background" Value="#0E1A2A"/><Setter Property="Foreground" Value="#D0E4F4"/>
      <Setter Property="Padding" Value="10,7"/>
      <Style.Triggers>
        <Trigger Property="IsMouseOver" Value="True"><Setter Property="Background" Value="#1A3050"/><Setter Property="Foreground" Value="#00D9FF"/></Trigger>
        <Trigger Property="IsSelected"  Value="True"><Setter Property="Background" Value="#0A1E38"/><Setter Property="Foreground" Value="#00D9FF"/></Trigger>
      </Style.Triggers>
    </Style>

  </Window.Resources>

  <Grid>
    <!-- HEADER -->
    <Border Height="96" VerticalAlignment="Top">
      <Border.Background><LinearGradientBrush StartPoint="0,0" EndPoint="1,0">
        <GradientStop Color="#040A14" Offset="0"/><GradientStop Color="#0A1C38" Offset="0.5"/><GradientStop Color="#040A14" Offset="1"/>
      </LinearGradientBrush></Border.Background>
      <Border.Effect><DropShadowEffect Color="#000000" BlurRadius="12" ShadowDepth="3" Opacity="0.6"/></Border.Effect>
      <Grid>
        <StackPanel VerticalAlignment="Center" HorizontalAlignment="Left" Margin="20,0">
          <TextBlock Text="&#x1F6E1;" FontSize="26" Foreground="#00D9FF" VerticalAlignment="Center"/>
        </StackPanel>
        <StackPanel VerticalAlignment="Center">
          <TextBlock Text="WINDOWS OPTIMIZER PRO V5.2" FontSize="24" FontWeight="Bold" FontFamily="Segoe UI" HorizontalAlignment="Center">
            <TextBlock.Foreground><LinearGradientBrush StartPoint="0,0" EndPoint="1,0">
              <GradientStop Color="#00D9FF" Offset="0"/><GradientStop Color="#FFFFFF" Offset="0.45"/><GradientStop Color="#00FF88" Offset="1"/>
            </LinearGradientBrush></TextBlock.Foreground>
          </TextBlock>
          <TextBlock Text="Otimizacao segura, reversivel e honesta — sem exageros" FontSize="12" Foreground="#445566" HorizontalAlignment="Center" Margin="0,5,0,0" FontFamily="Segoe UI"/>
        </StackPanel>
        <StackPanel VerticalAlignment="Top" HorizontalAlignment="Right" Margin="0,12,20,0" Orientation="Horizontal">
          <Border Background="#00D9FF" CornerRadius="6" Padding="9,3" Margin="0,0,8,0">
            <TextBlock Text="V5.2 PRO" FontSize="10" FontWeight="Bold" Foreground="#040A14"/>
          </Border>
          <TextBlock Name="txtGamerBadge" Text="" Foreground="#00FF88" FontSize="10" FontWeight="Bold" VerticalAlignment="Center"/>
        </StackPanel>
      </Grid>
    </Border>

    <!-- TOAST FEEDBACK -->
    <Border Name="toastBorder" VerticalAlignment="Top" HorizontalAlignment="Center" Margin="0,98,0,0"
            Background="#1A3A20" CornerRadius="10" Padding="20,10" Visibility="Collapsed" Panel.ZIndex="99">
      <Border.Effect><DropShadowEffect Color="#00FF88" BlurRadius="14" ShadowDepth="0" Opacity="0.4"/></Border.Effect>
      <TextBlock Name="txtToast" Text="" Foreground="#00FF88" FontSize="14" FontWeight="SemiBold" FontFamily="Segoe UI"/>
    </Border>

    <!-- ABAS -->
    <TabControl Margin="8,100,8,60" Background="#0A0E18" BorderThickness="0" Padding="0">

      <!-- ABA SISTEMA -->
      <TabItem Header="SISTEMA">
        <Grid Background="#0A0E18">
          <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="330"/></Grid.ColumnDefinitions>
          <!-- ESQUERDA: analise + top procs -->
          <Grid Grid.Column="0">
            <Grid.RowDefinitions><RowDefinition Height="*"/><RowDefinition Height="210"/></Grid.RowDefinitions>
            <ScrollViewer Grid.Row="0" VerticalScrollBarVisibility="Auto" Margin="16,14,8,6">
              <TextBlock Name="txtSystemInfo" Text="Carregando analise heuristica..." Foreground="#B0C8E0" FontSize="13" FontFamily="Consolas,Cascadia Code" TextWrapping="Wrap" LineHeight="20"/>
            </ScrollViewer>
            <!-- TOP PROCESSOS -->
            <Border Grid.Row="1" Background="#080D18" Margin="16,0,8,14" CornerRadius="12" BorderBrush="#1A2E48" BorderThickness="1">
              <Border.Effect><DropShadowEffect Color="#000000" BlurRadius="8" ShadowDepth="1" Opacity="0.4"/></Border.Effect>
              <Grid Margin="14,10">
                <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
                <TextBlock Grid.Row="0" Text="TOP PROCESSOS — TEMPO REAL (atualiza a cada 8s)" Foreground="#00D9FF" FontSize="12" FontWeight="Bold" FontFamily="Segoe UI" Margin="0,0,0,8"/>
                <ScrollViewer Grid.Row="1" VerticalScrollBarVisibility="Auto">
                  <TextBlock Name="txtTopProcs" Text="Carregando..." Foreground="#99BBCC" FontSize="12" FontFamily="Consolas,Cascadia Code" TextWrapping="Wrap"/>
                </ScrollViewer>
              </Grid>
            </Border>
          </Grid>
          <!-- DIREITA: score + acoes -->
          <StackPanel Grid.Column="1" Margin="6,14,16,14">
            <!-- SCORE CARD -->
            <Border Background="#0C1624" CornerRadius="12" Padding="16,14" Margin="0,0,0,10">
              <Border.Effect><DropShadowEffect Color="#00D9FF" BlurRadius="14" ShadowDepth="0" Opacity="0.15"/></Border.Effect>
              <StackPanel>
                <TextBlock Text="SCORE HEURISTICO" FontSize="12" FontWeight="Bold" Foreground="#445566" FontFamily="Segoe UI" Margin="0,0,0,6" HorizontalAlignment="Center"/>
                <TextBlock Name="txtScoreValue" Text="..." FontSize="36" FontWeight="Bold" Foreground="#00FF88" HorizontalAlignment="Center" FontFamily="Segoe UI"/>
                <TextBlock Name="txtScoreLabel" Text="Calculando..." FontSize="13" Foreground="#556677" HorizontalAlignment="Center" Margin="0,4,0,8"/>
                <TextBlock Text="PERFIL DE ANALISE:" FontSize="11" Foreground="#667788" Margin="0,0,0,5" FontFamily="Segoe UI"/>
                <ComboBox Name="cmbAIProfile" Height="34">
                  <ComboBoxItem Content="Padrao"   Tag="Padrao"   IsSelected="True"/>
                  <ComboBoxItem Content="Gamer"    Tag="Gamer"/>
                  <ComboBoxItem Content="Trabalho" Tag="Trabalho"/>
                </ComboBox>
                <Button Name="btnRefreshInfo" Content="Atualizar Analise" Height="36" Background="#182838" Foreground="#AABBCC" FontSize="12" Margin="0,8,0,0"/>
              </StackPanel>
            </Border>
            <!-- ACOES -->
            <TextBlock Text="ACOES PRINCIPAIS" FontSize="13" FontWeight="Bold" Foreground="#00D9FF" Margin="0,0,0,6" FontFamily="Segoe UI"/>
            <Button Name="btnSnapshot"    Content="Capturar Estado ANTES"             Height="46" Background="#22441A" Foreground="#88FF66" FontSize="13" Margin="0,2"/>
            <Button Name="btnCompare"     Content="Ver Comparativo Antes vs Depois"   Height="46" Background="#1A3A44" Foreground="#66DDFF" FontSize="13" Margin="0,2"/>
            <Button Name="btnAIOptimize"  Content="Otimizacao Heuristica Inteligente" Height="48" Background="#0055AA" Foreground="White"   FontSize="14" FontWeight="Bold" Margin="0,4"/>
            <Button Name="btnTelemetry"   Content="Desabilitar Telemetria"            Height="40" Background="#2A3344" Foreground="White"   FontSize="13" Margin="0,2"/>
            <Button Name="btnEnableTel"   Content="Reativar Telemetria (padrao MS)"   Height="40" Background="#1A2238" Foreground="#7799AA" FontSize="12" Margin="0,2"/>
            <Button Name="btnRestore"     Content="Criar Ponto de Restauracao"        Height="40" Background="#1A5030" Foreground="White"   FontSize="13" Margin="0,2"/>
            <Button Name="btnStartup"     Content="Startup Manager"                   Height="40" Background="#442266" Foreground="White"   FontSize="13" Margin="0,2"/>
            <Button Name="btnRAMClean"    Content="Limpar RAM (WorkingSet)"           Height="40" Background="#3A4400" Foreground="White"   FontSize="13" Margin="0,2"/>
            <Button Name="btnThirdTasks"  Content="Analisar Tasks de Terceiros"       Height="40" Background="#443300" Foreground="White"   FontSize="13" Margin="0,2"/>
            <Button Name="btnEventLog"    Content="Ver Erros Criticos"               Height="40" Background="#442200" Foreground="White"   FontSize="13" Margin="0,2"/>
            <Button Name="btnExportReport" Content="Exportar Relatorio TXT"          Height="40" Background="#223344" Foreground="#AABBCC" FontSize="12" Margin="0,2"/>
            <!-- HISTORICO -->
            <Separator Background="#1A2A3A" Margin="0,10"/>
            <TextBlock Text="HISTORICO DE SCORES" FontSize="11" FontWeight="Bold" Foreground="#445566" FontFamily="Segoe UI" Margin="0,0,0,5"/>
            <Border Background="#080D18" CornerRadius="8" Padding="10,8">
              <TextBlock Name="txtScoreHistory" Text="Sem historico" Foreground="#445566" FontSize="11" FontFamily="Consolas" TextWrapping="Wrap"/>
            </Border>
          </StackPanel>
        </Grid>
      </TabItem>

      <!-- ABA DISCO -->
      <TabItem Header="DISCO">
        <ScrollViewer VerticalScrollBarVisibility="Auto" Background="#0A0E18">
          <StackPanel Margin="20,16,20,20">

            <TextBlock Text="LIMPEZA DO SISTEMA" FontSize="17" FontWeight="Bold" Foreground="#00D9FF" Margin="0,0,0,10" FontFamily="Segoe UI"/>
            <Border Background="#0A1208" CornerRadius="10" Padding="16,12" Margin="0,0,0,12">
              <TextBlock FontSize="13" Foreground="#889966" FontFamily="Segoe UI" TextWrapping="Wrap" LineHeight="20">
                Limpeza Profunda: Temp, Prefetch, SoftwareDistribution\Download (apenas pacotes ja aplicados),
                WER Dumps, INet Cache, Lixeira, DNS. 100% seguro e reversivel.
              </TextBlock>
            </Border>
            <Grid Margin="0,0,0,6"><Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition/></Grid.ColumnDefinitions>
              <Button Grid.Column="0" Name="btnDeepClean"       Content="Limpeza Profunda do Sistema"       Height="52" Background="#1A5030" Foreground="White" FontSize="14" FontWeight="Bold" Margin="0,0,6,0"/>
              <Button Grid.Column="1" Name="btnPostUpdateClean" Content="Limpeza Pos-Atualizacao Windows"   Height="52" Background="#50301A" Foreground="White" FontSize="14" FontWeight="Bold" Margin="6,0,0,0"/>
            </Grid>
            <Grid Margin="0,0,0,0"><Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition/></Grid.ColumnDefinitions>
              <Button Grid.Column="0" Name="btnDiskCleanup"  Content="Limpeza de Disco (cleanmgr)"         Height="48" Background="#1A3060" Foreground="White" FontSize="13" FontWeight="Bold" Margin="0,0,6,0"/>
              <Button Grid.Column="1" Name="btnAutoSchedule" Content="Agendar Limpeza Semanal Automatica"  Height="48" Background="#30185A" Foreground="White" FontSize="13" FontWeight="Bold" Margin="6,0,0,0"/>
            </Grid>

            <Separator Background="#1A2838" Margin="0,18"/>
            <TextBlock Text="PAGEFILE — MEMORIA VIRTUAL" FontSize="17" FontWeight="Bold" Foreground="#00D9FF" Margin="0,0,0,10" FontFamily="Segoe UI"/>
            <Border Background="#0A1820" CornerRadius="10" Padding="16,12" Margin="0,0,0,12">
              <TextBlock FontSize="13" Foreground="#7799AA" FontFamily="Segoe UI" TextWrapping="Wrap" LineHeight="20">
                Formula Microsoft: Inicial = 1x RAM | Maximo = 3x RAM (teto 32 GB).
                Em SSDs modernos, o gerenciamento automatico costuma ser melhor.
                Use configuracao manual so se souber o que esta fazendo.
              </TextBlock>
            </Border>
            <Grid><Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition/></Grid.ColumnDefinitions>
              <Button Grid.Column="0" Name="btnPagefile"        Content="Configurar PageFile (Formula Microsoft)" Height="48" Background="#003850" Foreground="White" FontSize="13" FontWeight="Bold" Margin="0,0,6,0"/>
              <Button Grid.Column="1" Name="btnPagefileRestore" Content="Restaurar Gerenciamento Automatico"      Height="48" Background="#1A1A2A" Foreground="#7799AA" FontSize="12" Margin="6,0,0,0"/>
            </Grid>

            <Separator Background="#1A2838" Margin="0,18"/>
            <TextBlock Text="ATUALIZACAO DE APPS (WINGET)" FontSize="17" FontWeight="Bold" Foreground="#00D9FF" Margin="0,0,0,10" FontFamily="Segoe UI"/>
            <Grid><Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition/></Grid.ColumnDefinitions>
              <Button Grid.Column="0" Name="btnWingetList"    Content="Listar Apps com Atualizacao"       Height="46" Background="#1A301A" Foreground="White" FontSize="13" Margin="0,0,6,0"/>
              <Button Grid.Column="1" Name="btnWingetUpgrade" Content="Atualizar Todos (winget --all)"    Height="46" Background="#28A745" Foreground="White" FontSize="14" FontWeight="Bold" Margin="6,0,0,0"/>
            </Grid>

            <Separator Background="#1A2838" Margin="0,18"/>
            <TextBlock Text="CACHE DE NAVEGADORES" FontSize="17" FontWeight="Bold" Foreground="#00D9FF" Margin="0,0,0,6" FontFamily="Segoe UI"/>
            <Border Background="#060E1C" CornerRadius="8" Padding="12,8" Margin="0,0,0,10">
              <TextBlock FontSize="12" Foreground="#7799AA" FontFamily="Segoe UI" TextWrapping="Wrap">Edge Deep Clean: fecha o Edge e limpa Cache, Code Cache, GPUCache, ShaderCache, Service Worker e WebStorage. Dados pessoais (senhas, favoritos, historico) nao sao tocados.</TextBlock>
            </Border>
            <Button Name="btnEdgeDeepClean" Content="Edge LIMPEZA PROFUNDA (fecha Edge + limpa todos os caches)" Height="50" Background="#00204A" Foreground="#00AAFF" FontSize="13" FontWeight="Bold" Margin="0,0,0,8"/>
            <UniformGrid Columns="2" Rows="2">
              <Button Name="btnCleanEdge"    Content="Edge (cache basico)"      Height="42" Background="#003A80" Foreground="White" FontSize="12" Margin="0,0,5,5"/>
              <Button Name="btnCleanChrome"  Content="Limpar Google Chrome"     Height="42" Background="#1A3A90" Foreground="White" FontSize="12" Margin="5,0,0,5"/>
              <Button Name="btnCleanFirefox" Content="Limpar Mozilla Firefox"   Height="42" Background="#6A2000" Foreground="White" FontSize="12" Margin="0,0,5,0"/>
              <Button Name="btnCleanBrave"   Content="Limpar Brave Browser"     Height="42" Background="#5A1800" Foreground="White" FontSize="12" Margin="5,0,0,0"/>
            </UniformGrid>

            <Separator Background="#1A2838" Margin="0,18"/>
            <TextBlock Text="OTIMIZACAO DE DISCO" FontSize="17" FontWeight="Bold" Foreground="#00D9FF" Margin="0,0,0,8" FontFamily="Segoe UI"/>
            <Button Name="btnTrimAdvanced" Content="TRIM Avancado — Get-Volume (todos os volumes fixos)" Height="50" Background="#003850" Foreground="#00CCFF" FontSize="13" FontWeight="Bold" Margin="0,0,0,8"/>
            <Grid><Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition/></Grid.ColumnDefinitions>
              <Button Grid.Column="0" Name="btnOptimizeSSD" Content="TRIM Basico (por drive C:)"  Height="44" Background="#004460" Foreground="White" FontSize="12" Margin="0,0,6,0"/>
              <Button Grid.Column="1" Name="btnOptimizeHDD" Content="Desfragmentar HDD"           Height="44" Background="#2A2A2A" Foreground="White" FontSize="12" Margin="6,0,0,0"/>
            </Grid>

          </StackPanel>
        </ScrollViewer>
      </TabItem>

      <!-- ABA DRIVERS -->
      <TabItem Header="DRIVERS">
        <ScrollViewer VerticalScrollBarVisibility="Auto" Background="#0A0E18">
          <StackPanel Margin="20,16,20,20">
            <TextBlock Text="CACHE DE DRIVERS E DIRECTX" FontSize="17" FontWeight="Bold" Foreground="#00D9FF" Margin="0,0,0,12" FontFamily="Segoe UI"/>
            <Border Background="#0A1220" CornerRadius="10" Padding="16,12" Margin="0,0,0,16">
              <TextBlock FontSize="13" Foreground="#7799AA" TextWrapping="Wrap" FontFamily="Segoe UI" LineHeight="20">
                Cache de shaders acumula GB ao longo do tempo. Limpar e 100% seguro — recriado automaticamente ao usar apps e jogos.
              </TextBlock>
            </Border>
            <Button Name="btnCleanDX"     Content="Limpar Cache DirectX + D3DSCache + Shaders"             Height="52" Background="#0E1E3A" Foreground="White" FontSize="15" FontWeight="Bold" Margin="0,0,0,10"/>
            <Button Name="btnCleanNVIDIA" Content="Limpar Cache NVIDIA (DXCache + GLCache + ComputeCache)" Height="48" Background="#061A04" Foreground="#76B900" FontSize="14" Margin="0,0,0,7"/>
            <Button Name="btnCleanAMD"   Content="Limpar Cache AMD Radeon"                                 Height="48" Background="#1E0404" Foreground="#ED1C24" FontSize="14" Margin="0,0,0,7"/>
            <Button Name="btnCleanIntel" Content="Limpar Shader Cache Intel Graphics"                      Height="48" Background="#04081E" Foreground="#0096D6" FontSize="14"/>
          </StackPanel>
        </ScrollViewer>
      </TabItem>

      <!-- ABA REDE -->
      <TabItem Header="REDE">
        <Grid Background="#0A0E18">
          <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
          <ScrollViewer Grid.Row="0" MaxHeight="260" VerticalScrollBarVisibility="Auto" Margin="16,14,16,8">
            <TextBlock Name="txtNetworkInfo" Text="Analisando rede..." Foreground="#B0C8E0" FontSize="13" FontFamily="Consolas,Cascadia Code" TextWrapping="Wrap" LineHeight="20"/>
          </ScrollViewer>
          <ScrollViewer Grid.Row="1" VerticalScrollBarVisibility="Auto">
            <StackPanel Margin="16,8,16,16">
              <TextBlock Text="CORRECOES BASICAS" FontSize="16" FontWeight="Bold" Foreground="#00D9FF" Margin="0,0,0,10" FontFamily="Segoe UI"/>
              <UniformGrid Columns="2">
                <Button Name="btnDNS"         Content="Limpar Cache DNS"        Height="44" Background="#062838" Foreground="White" FontSize="13" Margin="0,0,5,5"/>
                <Button Name="btnWinsock"     Content="Resetar Winsock"         Height="44" Background="#062838" Foreground="White" FontSize="13" Margin="5,0,0,5"/>
                <Button Name="btnTCPIP"       Content="Resetar TCP/IP"          Height="44" Background="#062838" Foreground="White" FontSize="13" Margin="0,0,5,5"/>
                <Button Name="btnTCPOptimize" Content="Otimizacao TCP Avancada" Height="44" Background="#062A10" Foreground="White" FontSize="13" Margin="5,0,0,5"/>
              </UniformGrid>
              <TextBlock Text="DNS INTELIGENTE" FontSize="14" FontWeight="Bold" Foreground="#00D9FF" Margin="0,10,0,8" FontFamily="Segoe UI"/>
              <UniformGrid Columns="4">
                <Button Name="btnDNSGoogle"     Content="Google DNS"     Height="42" Background="#0A1A44" Foreground="White" FontSize="12" Margin="0,0,4,0"/>
                <Button Name="btnDNSCloudflare" Content="Cloudflare DNS" Height="42" Background="#3A1A00" Foreground="White" FontSize="12" Margin="4,0,4,0"/>
                <Button Name="btnDNSOpenDNS"    Content="OpenDNS"        Height="42" Background="#001A10" Foreground="White" FontSize="12" Margin="4,0,4,0"/>
                <Button Name="btnDNSRestore"    Content="Restaurar DNS (DHCP)" Height="42" Background="#1A1A1A" Foreground="#888888" FontSize="11" Margin="4,0,0,0"/>
              </UniformGrid>
              <TextBlock Text="OTIMIZACAO AVANCADA DE ADAPTADOR" FontSize="14" FontWeight="Bold" Foreground="#00D9FF" Margin="0,14,0,8" FontFamily="Segoe UI"/>
              <Border Background="#060E1A" CornerRadius="8" Padding="14,10" Margin="0,0,0,10">
                <TextBlock FontSize="12" Foreground="#7799AA" FontFamily="Segoe UI" TextWrapping="Wrap" LineHeight="18">Configura RSS, LSOv2, Interrupt Moderation e Flow Control direto no driver. Reduz latencia e melhora throughput. Totalmente reversivel.</TextBlock>
              </Border>
              <Grid><Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition/></Grid.ColumnDefinitions>
                <Button Grid.Column="0" Name="btnNetAdapterAdv"     Content="Aplicar Otimizacao Avancada (RSS + LSOv2 + IMod)" Height="50" Background="#063850" Foreground="White" FontSize="13" FontWeight="Bold" Margin="0,0,6,0"/>
                <Button Grid.Column="1" Name="btnNetAdapterRestore" Content="Restaurar Configuracoes de Rede Padrao"           Height="50" Background="#1A1A1A" Foreground="#888888" FontSize="12" Margin="6,0,0,0"/>
              </Grid>
              <Button Name="btnNetworkFull" Content="CORRECAO COMPLETA DE REDE (Requer Reinicio)" Height="52" Background="#500000" Foreground="White" FontSize="15" FontWeight="Bold" Margin="0,12,0,6"/>
              <Button Name="btnRefreshNet"  Content="Atualizar Analise de Rede" Height="38" Background="#141E2E" Foreground="#AABBCC" FontSize="13"/>
            </StackPanel>
          </ScrollViewer>
        </Grid>
      </TabItem>

      <!-- ABA REPAROS -->
      <TabItem Header="REPAROS">
        <ScrollViewer VerticalScrollBarVisibility="Auto" Background="#0A0E18">
          <StackPanel Margin="20,16,20,20">
            <TextBlock Text="REPARO DO SISTEMA WINDOWS" FontSize="17" FontWeight="Bold" Foreground="#00D9FF" Margin="0,0,0,10" FontFamily="Segoe UI"/>
            <Border Background="#0A1208" CornerRadius="10" Padding="16,12" Margin="0,0,0,16">
              <TextBlock FontSize="13" Foreground="#778855" TextWrapping="Wrap" FontFamily="Segoe UI" LineHeight="20">
                DISM e SFC rodam em CMD externo — o app nao trava. Nao feche a janela CMD ate concluir (pode levar 20-40 minutos).
                Nao desativa Defender, Atualizações ou Firewall.
              </TextBlock>
            </Border>
            <Grid Margin="0,0,0,10"><Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition/></Grid.ColumnDefinitions>
              <Button Grid.Column="0" Name="btnDISMScan"   Content="DISM — Verificar Saude do Sistema"  Height="52" Background="#382A00" Foreground="White" FontSize="14" Margin="0,0,6,0"/>
              <Button Grid.Column="1" Name="btnDISMRepair" Content="DISM — Reparar Sistema"             Height="52" Background="#402000" Foreground="White" FontSize="14" Margin="6,0,0,0"/>
            </Grid>
            <Grid><Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition/></Grid.ColumnDefinitions>
              <Button Grid.Column="0" Name="btnSFC"        Content="SFC — Verificar Arquivos do Sistema"  Height="52" Background="#003040" Foreground="White" FontSize="14" Margin="0,0,6,0"/>
              <Button Grid.Column="1" Name="btnRepairFull" Content="Reparo Completo DISM + SFC"           Height="52" Background="#480018" Foreground="White" FontSize="14" FontWeight="Bold" Margin="6,0,0,0"/>
            </Grid>
          </StackPanel>
        </ScrollViewer>
      </TabItem>

      <!-- ABA GAMER -->
      <TabItem Header="GAMER">
        <ScrollViewer VerticalScrollBarVisibility="Auto" Background="#0A0E18">
          <StackPanel HorizontalAlignment="Center" Width="500" Margin="0,20">
            <TextBlock Text="MODO GAMER V5.2" FontSize="28" FontWeight="Bold" Foreground="White" HorizontalAlignment="Center" FontFamily="Segoe UI"/>
            <TextBlock Text="Otimizacoes persistentes — sobrevivem ao reboot" FontSize="13" Foreground="#556677" HorizontalAlignment="Center" Margin="0,6,0,20" FontFamily="Segoe UI"/>
            <Border CornerRadius="14" Padding="30,24" Margin="0,0,0,16" BorderThickness="1.5">
              <Border.Background><LinearGradientBrush StartPoint="0,0" EndPoint="1,1"><GradientStop Color="#080E08" Offset="0"/><GradientStop Color="#0A180A" Offset="1"/></LinearGradientBrush></Border.Background>
              <Border.BorderBrush><LinearGradientBrush StartPoint="0,0" EndPoint="1,1"><GradientStop Color="#00FF88" Offset="0"/><GradientStop Color="#00AAFF" Offset="1"/></LinearGradientBrush></Border.BorderBrush>
              <Border.Effect><DropShadowEffect Color="#00FF88" BlurRadius="20" ShadowDepth="0" Opacity="0.2"/></Border.Effect>
              <StackPanel>
                <TextBlock Text="STATUS:" FontSize="12" Foreground="#445566" HorizontalAlignment="Center" FontFamily="Segoe UI"/>
                <Label Name="lblGamerStatus" Content="DESATIVADO" FontSize="24" FontWeight="Bold" Foreground="Red" HorizontalAlignment="Center" Margin="0,5,0,0" FontFamily="Segoe UI"/>
                <Button Name="btnGamerMode" Content="ATIVAR MODO GAMER" Height="54" Width="340" Background="#1A501A" Foreground="White" FontSize="17" FontWeight="Bold" Margin="0,18,0,0"/>
              </StackPanel>
            </Border>
            <!-- DESCRICAO CAUTELOSA -->
            <Border Background="#0C0C14" CornerRadius="12" Padding="22,18">
              <StackPanel>
                <TextBlock Text="O QUE ESTE MODO PODE FAZER (resultados variam):" FontSize="14" FontWeight="Bold" Foreground="#BBCCDD" Margin="0,0,0,12" FontFamily="Segoe UI"/>
                <TextBlock FontSize="13" Foreground="#8899AA" FontFamily="Segoe UI" TextWrapping="Wrap" LineHeight="22">
                  <Run Text="  Possivel ganho de 5-15% em FPS (depende do titulo, drivers e hardware)"/><LineBreak/>
                  <Run Text="  Possivel reducao de latencia de entrada em jogos de rede (Nagle OFF)"/><LineBreak/>
                  <Run Text="  Hardware-accelerated GPU Scheduling ON (recurso oficial Win 11)"/><LineBreak/>
                  <Run Text="  Prioridade alta para jogos no perfil de multimidia"/><LineBreak/>
                  <Run Text="  Persiste apos reinicializacao (via Task Scheduler)"/><LineBreak/>
                  <Run Text="  Cria ponto de restauracao automaticamente antes de aplicar"/><LineBreak/>
                  <Run Text="  PLANO DE ENERGIA: mantido padrao Windows (recomendado)"/>
                </TextBlock>
                <Separator Background="#1A2838" Margin="0,14"/>
                <TextBlock FontSize="12" Foreground="#664444" FontFamily="Segoe UI" TextWrapping="Wrap" LineHeight="20">
                  <Run Text="AVISO: Os ganhos reais dependem muito do seu sistema, drivers atualizados e do jogo."/><LineBreak/>
                  <Run Text="Nao espere milagres — melhorias sao modestas na maioria dos casos."/><LineBreak/>
                  <Run Text="Todas as alteracoes sao 100% reversiveis (basta desativar o modo)."/>
                </TextBlock>
              </StackPanel>
            </Border>
          </StackPanel>
        </ScrollViewer>
      </TabItem>

      <!-- ABA CONFIG -->
      <TabItem Header="CONFIG">
        <ScrollViewer VerticalScrollBarVisibility="Auto" Background="#0A0E18">
          <StackPanel Margin="36,20">
            <TextBlock Text="CONFIGURACOES" FontSize="17" FontWeight="Bold" Foreground="#00D9FF" Margin="0,0,0,18" FontFamily="Segoe UI"/>
            <TextBlock Text="Idioma / Language:" FontSize="14" Foreground="#AABBCC" Margin="0,0,0,8" FontFamily="Segoe UI"/>
            <ComboBox Name="cmbLanguage" Height="36" Width="240" HorizontalAlignment="Left">
              <ComboBoxItem Content="Portugues (Brasil)" Tag="ptBR" IsSelected="True"/>
              <ComboBoxItem Content="English (US)"       Tag="enUS"/>
            </ComboBox>
            <Separator Background="#1A2838" Margin="0,22"/>
            <TextBlock Text="LOG DE ACOES" FontSize="14" FontWeight="SemiBold" Foreground="White" Margin="0,0,0,10" FontFamily="Segoe UI"/>
            <Button Name="btnOpenLog" Content="Abrir Log de Acoes (WinOptimizer_Log.txt)" Height="40" Background="#182438" Foreground="#AABBCC" FontSize="12" HorizontalAlignment="Left" Width="340"/>
            <Separator Background="#1A2838" Margin="0,22"/>
            <TextBlock Text="SOBRE O PROJETO" FontSize="14" FontWeight="SemiBold" Foreground="White" Margin="0,0,0,12" FontFamily="Segoe UI"/>
            <Border Background="#0A1424" CornerRadius="12" Padding="22">
              <StackPanel>
                <TextBlock Text="Windows Optimizer Pro V5.2 ULTRA PRO" FontSize="15" FontWeight="Bold" Foreground="#00D9FF" FontFamily="Segoe UI"/>
                <TextBlock Text="GitHub: github.com/windows-optimizer-pro" FontSize="13" Foreground="#00FF88" Margin="0,6,0,0" FontFamily="Segoe UI"/>
                <TextBlock Text="Licenca: MIT Open Source 2026" FontSize="13" Foreground="#7799AA" Margin="0,4" FontFamily="Segoe UI"/>
                <TextBlock Text="Compativel: Windows 10 / 11 | PowerShell 5.1 e 7.x" FontSize="13" Foreground="#7799AA" FontFamily="Segoe UI"/>
                <Separator Background="#1A2838" Margin="0,12"/>
                <TextBlock FontSize="12" Foreground="#445566" FontFamily="Segoe UI" LineHeight="20">
                  <Run Text="SEGURANCA: 8.5/10 — nunca toca Defender/Update/Firewall"/><LineBreak/>
                  <Run Text="FUNCIONALIDADE: 8.5/10 — reversivel + backup + log"/><LineBreak/>
                  <Run Text="HEURISTICA: 6.5/10 — 12 metricas reais, sem ML"/><LineBreak/>
                  <Run Text="REVERSIBILIDADE: 9/10 — restauracao em tudo"/>
                </TextBlock>
              </StackPanel>
            </Border>
          </StackPanel>
        </ScrollViewer>
      </TabItem>

    </TabControl>

    <!-- RODAPE — DISCLAIMER FIXO + STATUS -->
    <Border Height="58" VerticalAlignment="Bottom">
      <Border.Background><LinearGradientBrush StartPoint="0,0" EndPoint="1,0">
        <GradientStop Color="#04080E" Offset="0"/><GradientStop Color="#08142A" Offset="0.5"/><GradientStop Color="#04080E" Offset="1"/>
      </LinearGradientBrush></Border.Background>
      <Grid Margin="16,0">
        <Grid.ColumnDefinitions><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
        <TextBlock Grid.Column="0" Name="txtSpaceFreed" Text="Liberado: 0 MB" Foreground="#00FF88" FontSize="13" FontWeight="SemiBold" VerticalAlignment="Center" FontFamily="Segoe UI"/>
        <TextBlock Grid.Column="1" Text="Ferramenta segura e reversivel. Nao desativa Defender, Atualizacoes ou Firewall. Crie ponto de restauracao antes de alteracoes." Foreground="#555566" FontSize="11" VerticalAlignment="Center" HorizontalAlignment="Center" FontFamily="Segoe UI" TextWrapping="NoWrap"/>
        <TextBlock Grid.Column="2" Name="txtStatusMsg" Text="" Foreground="#FFCC00" FontSize="12" VerticalAlignment="Center" FontFamily="Segoe UI" Margin="10,0,0,0"/>
      </Grid>
    </Border>

  </Grid>
</Window>
'@

$Reader = New-Object System.Xml.XmlNodeReader $XAML
$Window = [Windows.Markup.XamlReader]::Load($Reader)

# ── CONTROLES ──────────────────────────────────────────────
$txtSystemInfo    = $Window.FindName('txtSystemInfo')
$txtTopProcs      = $Window.FindName('txtTopProcs')
$txtSpaceFreed    = $Window.FindName('txtSpaceFreed')
$txtNetworkInfo   = $Window.FindName('txtNetworkInfo')
$txtScoreValue    = $Window.FindName('txtScoreValue')
$txtScoreLabel    = $Window.FindName('txtScoreLabel')
$txtStatusMsg     = $Window.FindName('txtStatusMsg')
$txtGamerBadge    = $Window.FindName('txtGamerBadge')
$txtScoreHistory  = $Window.FindName('txtScoreHistory')
$txtToast         = $Window.FindName('txtToast')
$toastBorder      = $Window.FindName('toastBorder')
$lblGamerStatus   = $Window.FindName('lblGamerStatus')
$cmbAIProfile     = $Window.FindName('cmbAIProfile')
$cmbLanguage      = $Window.FindName('cmbLanguage')

$btnSnapshot         = $Window.FindName('btnSnapshot')
$btnCompare          = $Window.FindName('btnCompare')
$btnAIOptimize       = $Window.FindName('btnAIOptimize')
$btnTelemetry        = $Window.FindName('btnTelemetry')
$btnEnableTel        = $Window.FindName('btnEnableTel')
$btnRestore          = $Window.FindName('btnRestore')
$btnStartup          = $Window.FindName('btnStartup')
$btnRAMClean         = $Window.FindName('btnRAMClean')
$btnThirdTasks       = $Window.FindName('btnThirdTasks')
$btnEventLog         = $Window.FindName('btnEventLog')
$btnExportReport     = $Window.FindName('btnExportReport')
$btnRefreshInfo      = $Window.FindName('btnRefreshInfo')
$btnPagefile         = $Window.FindName('btnPagefile')
$btnPagefileRestore  = $Window.FindName('btnPagefileRestore')
$btnDeepClean        = $Window.FindName('btnDeepClean')
$btnPostUpdateClean  = $Window.FindName('btnPostUpdateClean')
$btnDiskCleanup      = $Window.FindName('btnDiskCleanup')
$btnAutoSchedule     = $Window.FindName('btnAutoSchedule')
$btnWingetList       = $Window.FindName('btnWingetList')
$btnWingetUpgrade    = $Window.FindName('btnWingetUpgrade')
$btnCleanEdge        = $Window.FindName('btnCleanEdge')
$btnEdgeDeepClean    = $Window.FindName('btnEdgeDeepClean')
$btnTrimAdvanced     = $Window.FindName('btnTrimAdvanced')
$btnCleanChrome      = $Window.FindName('btnCleanChrome')
$btnCleanFirefox     = $Window.FindName('btnCleanFirefox')
$btnCleanBrave       = $Window.FindName('btnCleanBrave')
$btnOptimizeSSD      = $Window.FindName('btnOptimizeSSD')
$btnOptimizeHDD      = $Window.FindName('btnOptimizeHDD')
$btnCleanDX          = $Window.FindName('btnCleanDX')
$btnCleanNVIDIA      = $Window.FindName('btnCleanNVIDIA')
$btnCleanAMD         = $Window.FindName('btnCleanAMD')
$btnCleanIntel       = $Window.FindName('btnCleanIntel')
$btnDNS              = $Window.FindName('btnDNS')
$btnWinsock          = $Window.FindName('btnWinsock')
$btnTCPIP            = $Window.FindName('btnTCPIP')
$btnTCPOptimize      = $Window.FindName('btnTCPOptimize')
$btnNetAdapterAdv    = $Window.FindName('btnNetAdapterAdv')
$btnNetAdapterRestore= $Window.FindName('btnNetAdapterRestore')
$btnDNSGoogle        = $Window.FindName('btnDNSGoogle')
$btnDNSCloudflare    = $Window.FindName('btnDNSCloudflare')
$btnDNSOpenDNS       = $Window.FindName('btnDNSOpenDNS')
$btnDNSRestore       = $Window.FindName('btnDNSRestore')
$btnNetworkFull      = $Window.FindName('btnNetworkFull')
$btnRefreshNet       = $Window.FindName('btnRefreshNet')
$btnDISMScan         = $Window.FindName('btnDISMScan')
$btnDISMRepair       = $Window.FindName('btnDISMRepair')
$btnSFC              = $Window.FindName('btnSFC')
$btnRepairFull       = $Window.FindName('btnRepairFull')
$btnGamerMode        = $Window.FindName('btnGamerMode')
$btnOpenLog          = $Window.FindName('btnOpenLog')

# ── HELPERS UI ─────────────────────────────────────────────
function Set-Status { param([string]$M) $txtStatusMsg.Text = $M }

function Show-Toast {
    param([string]$Msg, [int]$Seconds = 5)
    $txtToast.Text = $Msg
    $toastBorder.Visibility = [System.Windows.Visibility]::Visible
    $t = New-Object System.Windows.Threading.DispatcherTimer
    $t.Interval = [TimeSpan]::FromSeconds($Seconds)
    $t.Add_Tick({
        $toastBorder.Visibility = [System.Windows.Visibility]::Collapsed
        $t.Stop()
    })
    $t.Start()
}

function Update-ScoreUI {
    param([int]$Score, [string]$Class)
    $txtScoreValue.Text = "$Score/1000"
    $txtScoreLabel.Text = $Class
    $col = if ($Score -ge 800) {"#00FF88"} elseif ($Score -ge 550) {"#FFAA00"} else {"#FF4444"}
    $txtScoreValue.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFrom($col)
}

function Refresh-History {
    $h = Get-ScoreHistory
    $txtScoreHistory.Text = if ($h) { $h -join "`n" } else { "Sem historico" }
}

# ── EVENTOS ────────────────────────────────────────────────
$btnSnapshot.Add_Click({
    Set-Status "Capturando estado..."
    $Global:SnapshotBefore = Get-SystemSnapshot
    Show-Toast "Estado capturado! Score: $($Global:SnapshotBefore.Score)/1000"
    Set-Status ""
})
$btnCompare.Add_Click({ Show-ComparisonReport })

$btnAIOptimize.Add_Click({
    Set-Status "Executando Otimizacao Heuristica..."
    Invoke-HeuristicOptimize
    $hs = Get-HeuristicScore -Profile (if($cmbAIProfile.SelectedItem){$cmbAIProfile.SelectedItem.Tag}else{'Padrao'})
    Update-ScoreUI $hs.Score $hs.Class
    Refresh-History
    Show-Toast "Otimizacao concluida! Score: $($hs.Score)/1000"
    Set-Status ""
})

$btnTelemetry.Add_Click({
    Set-Status "Desabilitando Telemetria..."
    Disable-Telemetry
    Show-Toast "Telemetria desabilitada!"
    Set-Status ""
})
$btnEnableTel.Add_Click({
    Enable-Telemetry
    Show-Toast "Telemetria reativada (padrao Microsoft)"
})
$btnRestore.Add_Click({ Set-Status "Criando ponto..."; New-RestorePoint; Set-Status "" })
$btnStartup.Add_Click({ Show-StartupManager })
$btnRAMClean.Add_Click({
    Set-Status "Limpando RAM..."
    Invoke-RAMClean
    Show-Toast "RAM limpa!"
    Set-Status ""
})
$btnThirdTasks.Add_Click({  Show-ThirdPartyTasks })
$btnEventLog.Add_Click({
    $e = Get-CriticalErrors
    [System.Windows.MessageBox]::Show($e, "Erros Criticos", "OK", "Warning")
})
$btnExportReport.Add_Click({
    Set-Status "Exportando..."
    Export-Report
    Show-Toast "Relatorio exportado na Area de Trabalho!"
    Set-Status ""
})
$btnRefreshInfo.Add_Click({
    Set-Status "Atualizando..."
    $profile = if($cmbAIProfile.SelectedItem){$cmbAIProfile.SelectedItem.Tag}else{'Padrao'}
    $txtSystemInfo.Text = Get-DetailedSystemInfo
    $hs = Get-HeuristicScore -Profile $profile
    Update-ScoreUI $hs.Score $hs.Class
    Save-ScoreHistory -Score $hs.Score -Class $hs.Class
    Refresh-History
    Set-Status ""
})
$cmbAIProfile.Add_SelectionChanged({
    if ($txtScoreValue.Text -ne "...") {
        $profile = if($cmbAIProfile.SelectedItem){$cmbAIProfile.SelectedItem.Tag}else{'Padrao'}
        $hs = Get-HeuristicScore -Profile $profile
        Update-ScoreUI $hs.Score $hs.Class
    }
})
$btnPagefile.Add_Click({       Set-Status "PageFile..."; Invoke-PagefileOptimize;       Set-Status "" })
$btnPagefileRestore.Add_Click({ Restore-PagefileAutomatic })
$btnDeepClean.Add_Click({
    Set-Status "Limpeza profunda..."
    Invoke-DeepClean
    Show-Toast "Limpeza concluida! Liberado: $([Math]::Round($Global:SpaceFreed/1MB,1)) MB"
    Set-Status ""
})
$btnPostUpdateClean.Add_Click({
    Set-Status "Limpeza pos-update..."
    Invoke-PostUpdateClean
    Show-Toast "Limpeza pos-update concluida!"
    Set-Status ""
})
$btnDiskCleanup.Add_Click({   Set-Status "Abrindo..."; Invoke-WindowsDiskCleanup; Set-Status "" })
$btnAutoSchedule.Add_Click({  Invoke-AutoSchedule })
$btnWingetList.Add_Click({    Invoke-WingetUpgrade -ListOnly $true })
$btnWingetUpgrade.Add_Click({ Invoke-WingetUpgrade -ListOnly $false })
$btnCleanEdge.Add_Click({     Set-Status "Limpando Edge...";    Clean-BrowserCache 'Edge';    Show-Toast "Cache Edge limpo!"; Set-Status "" })
$btnEdgeDeepClean.Add_Click({ Set-Status "Edge Deep Clean..."; Invoke-EdgeDeepClean; Show-Toast "Edge: limpeza profunda concluida!"; Set-Status "" })
$btnTrimAdvanced.Add_Click({  Set-Status "TRIM Avancado..."; Invoke-SSDTrimAdvanced; Show-Toast "TRIM Avancado concluido!"; Set-Status "" })
$btnCleanChrome.Add_Click({   Set-Status "Limpando Chrome...";  Clean-BrowserCache 'Chrome';  Show-Toast "Cache Chrome limpo!"; Set-Status "" })
$btnCleanFirefox.Add_Click({  Set-Status "Limpando Firefox..."; Clean-BrowserCache 'Firefox'; Show-Toast "Cache Firefox limpo!"; Set-Status "" })
$btnCleanBrave.Add_Click({    Set-Status "Limpando Brave...";   Clean-BrowserCache 'Brave';   Show-Toast "Cache Brave limpo!"; Set-Status "" })
$btnOptimizeSSD.Add_Click({   Set-Status "TRIM SSD...";          Optimize-Disk $true;  Set-Status "" })
$btnOptimizeHDD.Add_Click({   Set-Status "Desfragmentando...";   Optimize-Disk $false; Set-Status "" })
$btnCleanDX.Add_Click({       Set-Status "Limpando DX...";      Clean-DirectX;            Show-Toast "Cache DirectX limpo!"; Set-Status "" })
$btnCleanNVIDIA.Add_Click({   Set-Status "Limpando NVIDIA...";   Clean-GPUCache 'NVIDIA'; Show-Toast "Cache NVIDIA limpo!"; Set-Status "" })
$btnCleanAMD.Add_Click({      Set-Status "Limpando AMD...";      Clean-GPUCache 'AMD';    Show-Toast "Cache AMD limpo!"; Set-Status "" })
$btnCleanIntel.Add_Click({    Set-Status "Limpando Intel...";    Clean-GPUCache 'Intel';  Show-Toast "Cache Intel limpo!"; Set-Status "" })
$btnDNS.Add_Click({      ipconfig /flushdns|Out-Null; Show-Toast "Cache DNS limpo!"; [System.Windows.MessageBox]::Show("Cache DNS limpo!","DNS","OK","Information") })
$btnWinsock.Add_Click({  try{netsh winsock reset 2>$null|Out-Null; [System.Windows.MessageBox]::Show("Winsock resetado! Reinicie.","Winsock","OK","Warning")}catch{} })
$btnTCPIP.Add_Click({    try{netsh int ip reset 2>$null|Out-Null; [System.Windows.MessageBox]::Show("TCP/IP resetado! Reinicie.","TCPIP","OK","Warning")}catch{} })
$btnTCPOptimize.Add_Click({    Optimize-TCPNetwork })
$btnNetAdapterAdv.Add_Click({  Set-Status "Otimizando adaptadores..."; Invoke-NetworkAdapterAdvanced;  Show-Toast "Adaptadores otimizados!"; Set-Status "" })
$btnNetAdapterRestore.Add_Click({ Restore-NetworkAdapterDefaults })
$btnDNSGoogle.Add_Click({      Set-BestDNS 'Google' })
$btnDNSCloudflare.Add_Click({  Set-BestDNS 'Cloudflare' })
$btnDNSOpenDNS.Add_Click({     Set-BestDNS 'OpenDNS' })
$btnDNSRestore.Add_Click({     Restore-DNS })
$btnNetworkFull.Add_Click({    Repair-NetworkFull })
$btnRefreshNet.Add_Click({
    Set-Status "Analisando rede..."
    try { $txtNetworkInfo.Text = Get-NetworkAIAnalysis } catch { $txtNetworkInfo.Text = "Clique em Atualizar." }
    Set-Status ""
})
$btnDISMScan.Add_Click({   Start-ExternalRepair 'DISM_SCAN' })
$btnDISMRepair.Add_Click({ Start-ExternalRepair 'DISM_REPAIR' })
$btnSFC.Add_Click({        Start-ExternalRepair 'SFC' })
$btnRepairFull.Add_Click({ Start-ExternalRepair 'FULL_REPAIR' })
$btnGamerMode.Add_Click({  Toggle-GamerMode -StatusLabel $lblGamerStatus -Btn $btnGamerMode })
$btnOpenLog.Add_Click({
    if (Test-Path $Global:LogFile) { Start-Process "notepad.exe" $Global:LogFile }
    else { [System.Windows.MessageBox]::Show("Nenhum log gerado ainda.", "Log", "OK", "Information") }
})

# ── LOADED ─────────────────────────────────────────────────
$Window.Add_Loaded({
    if (Get-GamerModeState) {
        $lblGamerStatus.Content = "ATIVADO"
        $lblGamerStatus.Foreground = [System.Windows.Media.Brushes]::Lime
        $btnGamerMode.Background  = [System.Windows.Media.BrushConverter]::new().ConvertFrom("#DC3545")
        $btnGamerMode.Content     = "DESATIVAR MODO GAMER"
        $Global:GamerModeActive   = $true
        $txtGamerBadge.Text       = "GAMER ON"
    }
    $dispatcher = $Window.Dispatcher

    # Runspace — sistema + heuristica
    $sb_sys = (Get-Command Get-DetailedSystemInfo).ScriptBlock.ToString()
    $sb_hs  = (Get-Command Get-HeuristicScore).ScriptBlock.ToString()
    $sb_sh  = (Get-Command Save-ScoreHistory).ScriptBlock.ToString()

    $rs = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace(); $rs.Open()
    $ps = [System.Management.Automation.PowerShell]::Create(); $ps.Runspace = $rs
    $ps.AddScript({
        param($ss,$sh,$ssh)
        Invoke-Expression "function Get-DetailedSystemInfo { $ss }"
        Invoke-Expression "function Get-HeuristicScore { $sh }"
        Invoke-Expression "function Save-ScoreHistory { $ssh }"
        $info = Get-DetailedSystemInfo
        $hs   = Get-HeuristicScore -Profile 'Padrao'
        Save-ScoreHistory -Score $hs.Score -Class $hs.Class
        return @{ Info=$info; Score=$hs.Score; Class=$hs.Class }
    }).AddArgument($sb_sys).AddArgument($sb_hs).AddArgument($sb_sh) | Out-Null
    $h = $ps.BeginInvoke()

    $t = New-Object System.Windows.Threading.DispatcherTimer; $t.Interval = [TimeSpan]::FromMilliseconds(400)
    $t.Add_Tick({
        if ($h.IsCompleted) {
            $t.Stop()
            try {
                $r = $ps.EndInvoke($h)
                if ($r -and $r.Count -gt 0) {
                    $dispatcher.Invoke([Action]{
                        $txtSystemInfo.Text = $r[0].Info
                        Update-ScoreUI $r[0].Score $r[0].Class
                        Refresh-History
                    })
                }
            } catch { $dispatcher.Invoke([Action]{ $txtSystemInfo.Text = Get-DetailedSystemInfo }) }
            $ps.Dispose(); $rs.Close()
        }
    }); $t.Start()

    # Runspace — rede
    $sb_net = (Get-Command Get-NetworkAIAnalysis).ScriptBlock.ToString()
    $rs2 = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace(); $rs2.Open()
    $ps2 = [System.Management.Automation.PowerShell]::Create(); $ps2.Runspace = $rs2
    $ps2.AddScript({ param($sn); Invoke-Expression "function Get-NetworkAIAnalysis { $sn }"; return Get-NetworkAIAnalysis }).AddArgument($sb_net) | Out-Null
    $h2 = $ps2.BeginInvoke()
    $t2 = New-Object System.Windows.Threading.DispatcherTimer; $t2.Interval = [TimeSpan]::FromMilliseconds(400)
    $t2.Add_Tick({
        if ($h2.IsCompleted) {
            $t2.Stop()
            try { $r2=$ps2.EndInvoke($h2); $dispatcher.Invoke([Action]{ if($r2){$txtNetworkInfo.Text=$r2[0]}else{$txtNetworkInfo.Text="Clique em Atualizar."} }) } catch {}
            $ps2.Dispose(); $rs2.Close()
        }
    }); $t2.Start()

    # Timer Top Processos — 8s
    $timerProcs = New-Object System.Windows.Threading.DispatcherTimer; $timerProcs.Interval = [TimeSpan]::FromSeconds(8)
    $timerProcs.Add_Tick({ $txtTopProcs.Text = Get-TopProcesses })
    $timerProcs.Start()
    $txtTopProcs.Text = Get-TopProcesses

    # Timer rodape — 8s
    $timerFoot = New-Object System.Windows.Threading.DispatcherTimer; $timerFoot.Interval = [TimeSpan]::FromSeconds(8)
    $timerFoot.Add_Tick({
        $txtSpaceFreed.Text = "Liberado: $([Math]::Round($Global:SpaceFreed/1MB,2)) MB"
        $txtGamerBadge.Text = if($Global:GamerModeActive){"GAMER ON"}else{""}
    })
    $timerFoot.Start()

    Write-Log "Aplicacao iniciada" "V5.2"
})

$Window.ShowDialog() | Out-Null
